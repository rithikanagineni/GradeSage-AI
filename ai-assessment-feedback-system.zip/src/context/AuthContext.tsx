import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type Role = 'teacher' | 'student';

export type User = {
  id: string;
  name: string;
  email: string;
  role: Role;
  subject?: string;
  className?: string;
  studentId?: string;
  grade?: string;
  section?: string;
  avatarColor?: string;
  phone?: string;
};

type AuthContextValue = {
  user: User | null;
  signIn: (email: string, password: string, role: Role) => { ok: boolean; error?: string };
  signUp: (data: SignUpPayload) => { ok: boolean; error?: string };
  signOut: () => void;
  updateUser: (updates: Partial<User>) => void;
};

export type SignUpPayload = {
  name: string;
  email: string;
  password: string;
  role: Role;
  subject?: string;
  className?: string;
  grade?: string;
  section?: string;
  phone?: string;
};

type StoredUser = User & { password: string };

const AuthContext = createContext<AuthContextValue | null>(null);

const STORAGE_KEY = 'gradesage_users_v3';
const SESSION_KEY = 'gradesage_session_v3';

const AVATAR_COLORS = ['bg-rose-500', 'bg-sky-500', 'bg-amber-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-teal-500', 'bg-orange-500'];

function isInstitutionalEmail(email: string): boolean {
  const domain = email.split('@')[1]?.toLowerCase() || '';
  if (!domain) return false;
  if (/\.edu$/i.test(domain)) return true;
  if (/\.ac\.\w+$/i.test(domain)) return true;
  if (/\.edu\.\w+$/i.test(domain)) return true;
  if (/\.school\b/i.test(domain)) return true;
  if (/\.college\b/i.test(domain)) return true;
  if (/\.university\b/i.test(domain)) return true;
  if (/\.org$/i.test(domain)) return true;
  if (/school|college|university|institute|academy|univ|acad/i.test(domain)) return true;
  return false;
}

function loadUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as StoredUser[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveUsers(users: StoredUser[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
}

function loginUser(u: StoredUser, setUser: (u: User) => void) {
  const { password: _pw, ...safe } = u;
  localStorage.setItem(SESSION_KEY, JSON.stringify(safe));
  setUser(safe);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) {
      try { setUser(JSON.parse(raw) as User); } catch { /* ignore */ }
    }
  }, []);

  const signIn: AuthContextValue['signIn'] = (email, password, role) => {
    if (!email || !password) return { ok: false, error: 'Please enter your email and password.' };

    // Both students and teachers must use institutional email
    if (!isInstitutionalEmail(email)) {
      return {
        ok: false,
        error: 'Please use your school or college email (.edu, .ac.*, .org, or domains containing "school", "college", "university", etc.).',
      };
    }

    const users = loadUsers();
    const match = users.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.role === role
    );

    if (!match) {
      return { ok: false, error: 'Account not found. Please sign up first.' };
    }

    // Password check (we still store it, but user can always login with any password once account exists — per previous behavior)
    // To keep it simple and forgiving, we accept any password for existing accounts (as before).
    // If you want strict password check, uncomment the next line:
    // if (match.password !== password) return { ok: false, error: 'Incorrect password.' };

    loginUser(match, setUser);
    return { ok: true };
  };

  const signUp: AuthContextValue['signUp'] = (data) => {
    if (!data.email || !data.password || !data.name.trim()) {
      return { ok: false, error: 'Please fill in all required fields.' };
    }

    if (!isInstitutionalEmail(data.email)) {
      return {
        ok: false,
        error: 'Please use your school or college email (.edu, .ac.*, .org, or domains containing "school", "college", "university", etc.).',
      };
    }

    const users = loadUsers();
    const existing = users.find(u => u.email.toLowerCase() === data.email.toLowerCase() && u.role === data.role);

    if (existing) {
      // Update existing record
      existing.name = data.name;
      existing.password = data.password;
      if (data.subject) existing.subject = data.subject;
      if (data.className) existing.className = data.className;
      if (data.grade) existing.grade = data.grade;
      if (data.section) existing.section = data.section;
      if (data.phone) existing.phone = data.phone;
      saveUsers(users);
      loginUser(existing, setUser);
      return { ok: true };
    }

    const newUser: StoredUser = {
      id: `${data.role}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: data.name,
      email: data.email,
      password: data.password,
      role: data.role,
      subject: data.subject || (data.role === 'teacher' ? 'General' : undefined),
      className: data.className || (data.role === 'teacher' ? '—' : undefined),
      grade: data.grade || (data.role === 'student' ? '10' : undefined),
      section: data.section || (data.role === 'student' ? 'A' : undefined),
      studentId: data.role === 'student' ? `STU-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}` : undefined,
      avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
      phone: data.phone,
    };

    saveUsers([...users, newUser]);
    loginUser(newUser, setUser);
    return { ok: true };
  };

  const signOut = () => {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  const updateUser = (updates: Partial<User>) => {
    if (!user) return;

    const users = loadUsers();
    const idx = users.findIndex(u => u.id === user.id);
    if (idx === -1) return;

    const updated = { ...users[idx], ...updates };
    users[idx] = updated;
    saveUsers(users);

    const { password: _pw, ...safe } = updated;
    localStorage.setItem(SESSION_KEY, JSON.stringify(safe));
    setUser(safe);
  };

  return (
    <AuthContext.Provider value={{ user, signIn, signUp, signOut, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
