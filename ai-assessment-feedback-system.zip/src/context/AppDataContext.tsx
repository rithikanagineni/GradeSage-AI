import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Assignment, Student, Submission } from '../types';

const DATA_KEY = 'gradesage_app_data_v1';

export type AppData = {
  students: Student[];
  assignments: Assignment[];
  submissions: Submission[];
};

type AppDataContextValue = {
  data: AppData;
  setStudents: (students: Student[]) => void;
  setAssignments: (assignments: Assignment[]) => void;
  setSubmissions: (submissions: Submission[]) => void;
  addStudent: (student: Student) => void;
  addAssignment: (assignment: Assignment) => void;
  addSubmission: (submission: Submission) => void;
  updateSubmission: (id: string, updates: Partial<Submission>) => void;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  updateAssignment: (id: string, updates: Partial<Assignment>) => void;
  clearAllData: () => void;
};

const defaultData: AppData = {
  students: [],
  assignments: [],
  submissions: [],
};

const AppDataContext = createContext<AppDataContextValue | null>(null);

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(DATA_KEY);
    if (!raw) return { ...defaultData };
    const parsed = JSON.parse(raw);
    return {
      students: Array.isArray(parsed.students) ? parsed.students : [],
      assignments: Array.isArray(parsed.assignments) ? parsed.assignments : [],
      submissions: Array.isArray(parsed.submissions) ? parsed.submissions : [],
    };
  } catch {
    return { ...defaultData };
  }
}

function saveData(data: AppData) {
  localStorage.setItem(DATA_KEY, JSON.stringify(data));
}

export function AppDataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());

  // Persist whenever data changes
  useEffect(() => {
    saveData(data);
  }, [data]);

  const setStudents = useCallback((students: Student[]) => {
    setData(prev => ({ ...prev, students }));
  }, []);

  const setAssignments = useCallback((assignments: Assignment[]) => {
    setData(prev => ({ ...prev, assignments }));
  }, []);

  const setSubmissions = useCallback((submissions: Submission[]) => {
    setData(prev => ({ ...prev, submissions }));
  }, []);

  const addStudent = useCallback((student: Student) => {
    setData(prev => ({
      ...prev,
      students: [...prev.students.filter(s => s.id !== student.id), student],
    }));
  }, []);

  const addAssignment = useCallback((assignment: Assignment) => {
    setData(prev => ({
      ...prev,
      assignments: [...prev.assignments.filter(a => a.id !== assignment.id), assignment],
    }));
  }, []);

  const addSubmission = useCallback((submission: Submission) => {
    setData(prev => ({
      ...prev,
      submissions: [...prev.submissions.filter(s => s.id !== submission.id), submission],
    }));
  }, []);

  const updateSubmission = useCallback((id: string, updates: Partial<Submission>) => {
    setData(prev => ({
      ...prev,
      submissions: prev.submissions.map(s =>
        s.id === id ? { ...s, ...updates } : s
      ),
    }));
  }, []);

  const updateStudent = useCallback((id: string, updates: Partial<Student>) => {
    setData(prev => ({
      ...prev,
      students: prev.students.map(s =>
        s.id === id ? { ...s, ...updates } : s
      ),
    }));
  }, []);

  const updateAssignment = useCallback((id: string, updates: Partial<Assignment>) => {
    setData(prev => ({
      ...prev,
      assignments: prev.assignments.map(a =>
        a.id === id ? { ...a, ...updates } : a
      ),
    }));
  }, []);

  const clearAllData = useCallback(() => {
    const empty = { ...defaultData };
    setData(empty);
    localStorage.setItem(DATA_KEY, JSON.stringify(empty));
  }, []);

  return (
    <AppDataContext.Provider
      value={{
        data,
        setStudents,
        setAssignments,
        setSubmissions,
        addStudent,
        addAssignment,
        addSubmission,
        updateSubmission,
        updateStudent,
        updateAssignment,
        clearAllData,
      }}
    >
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used inside AppDataProvider');
  return ctx;
}
