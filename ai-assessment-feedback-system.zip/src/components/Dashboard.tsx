import { Clock, CheckCircle2, AlertTriangle, TrendingUp, Zap, FileCheck, Sparkles, Brain, Database, ArrowRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import type { View } from '../types';
import { useAuth } from '../context/AuthContext';
import { useAppData } from '../context/AppDataContext';

export function Dashboard({ onNavigate }: { onNavigate: (v: View) => void }) {
  const { user } = useAuth();
  const { data } = useAppData();
  const { students, submissions } = data;
  const displayName = user?.name.split(' ').pop() || 'Teacher';

  const pending = submissions.filter(s => s.status === 'pending' || s.status === 'grading').length;
  const graded = submissions.filter(s => s.status === 'graded').length;
  const needsReview = submissions.filter(s => s.gradeResult?.humanReviewRecommended).length;
  const aiApprovedPct = graded > 0 ? Math.round(((graded - needsReview) / graded) * 100) : 0;

  // Weekly time saved data (simulated based on graded count)
  const weeklyTimeSaved = [
    { week: 'Wk 1', manualHours: graded * 0.4, aiHours: graded * 0.1 },
    { week: 'Wk 2', manualHours: graded * 0.5, aiHours: graded * 0.13 },
  ];
  const totalManual = weeklyTimeSaved.reduce((a, b) => a + b.manualHours, 0);
  const totalAI = weeklyTimeSaved.reduce((a, b) => a + b.aiHours, 0);

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-8 mb-6 text-white shadow-xl shadow-indigo-200">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
        <div className="relative flex items-center justify-between gap-6 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-5 w-5" />
              <span className="text-xs font-semibold uppercase tracking-wider text-indigo-100">Good morning, {displayName}</span>
            </div>
            <h1 className="text-3xl font-bold leading-tight mb-2">
              {graded > 0 ? `You've saved ${Math.max(0, Math.round(totalManual - totalAI))} hours of grading this week.` : 'Welcome to GradeSage'}
            </h1>
            <p className="text-indigo-100 max-w-2xl">Your multi-agent AI team (OpenAI + Claude + RAG) has processed <b>{graded}</b> submissions.</p>
            <div className="mt-5 flex gap-3">
              <button onClick={() => onNavigate('submissions')} className="inline-flex items-center gap-2 bg-white text-indigo-700 px-4 py-2 rounded-xl font-semibold text-sm hover:bg-indigo-50 transition">
                View submissions <ArrowRight className="h-4 w-4" />
              </button>
              <button onClick={() => onNavigate('assignments')} className="inline-flex items-center gap-2 bg-white/15 backdrop-blur text-white px-4 py-2 rounded-xl font-semibold text-sm hover:bg-white/25 transition border border-white/20">
                View assignments
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Stat icon={Clock} label="Students" value={students.length} iconClass="bg-emerald-100 text-emerald-600" valueClass="text-emerald-700" />
        <Stat icon={FileCheck} label="Assignments created" value={data.assignments.length} iconClass="bg-indigo-100 text-indigo-600" />
        <Stat icon={CheckCircle2} label="Graded submissions" value={graded} sub={`${aiApprovedPct}% auto-approved`} iconClass="bg-violet-100 text-violet-600" />
        <Stat icon={AlertTriangle} label="Needs review" value={needsReview} iconClass="bg-amber-100 text-amber-600" valueClass="text-amber-700" />
      </div>

      {/* Needs attention */}
      {students.filter((s: any) => (s.averageScore || 0) < 80).length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm mb-6">
          <h3 className="font-bold text-slate-900 text-lg mb-4">Needs attention</h3>
          <div className="space-y-3">
            {students.filter((s: any) => (s.averageScore || 0) < 80).slice(0, 4).map((s: any) => (
              <div key={s.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-50">
                <div className={`h-10 w-10 rounded-full ${s.avatarColor} flex items-center justify-center text-white text-sm font-bold shrink-0`}>
                  {s.name.split(' ').map((n: string) => n[0]).join('')}
                </div>
                <div className="flex-1"><div className="font-semibold text-slate-900 text-sm">{s.name}</div></div>
                <div className="text-lg font-bold text-rose-600">{s.averageScore}%</div>
              </div>
            ))}
            <button onClick={() => onNavigate('students')} className="w-full text-center text-sm font-medium text-indigo-600 hover:text-indigo-700 py-2 rounded-lg hover:bg-indigo-50 transition">View all students →</button>
          </div>
        </div>
      )}

      {data.assignments.length === 0 && students.length === 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
          <Sparkles className="h-12 w-12 mx-auto text-indigo-300 mb-3" />
          <h3 className="font-bold text-slate-900 text-lg">Your GradeSage journey starts here</h3>
          <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">Create your first assignment, add students, and let the AI agents handle the grading.</p>
          <div className="flex gap-3 justify-center mt-5">
            <button onClick={() => onNavigate('assignments')} className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold">Create Assignment</button>
            <button onClick={() => onNavigate('students')} className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-semibold">Add Students</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value, sub, iconClass, valueClass }: any) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</div>
          <div className={`text-2xl font-bold mt-1 ${valueClass || 'text-slate-900'}`}>{value}</div>
          {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
        </div>
        <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${iconClass}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function AgentPill({ icon: Icon, label, sub, color }: any) {
  return (
    <div className={`flex items-center gap-2 px-3 py-2 rounded-xl ${color} backdrop-blur border border-white/20 shrink-0`}>
      <Icon className="h-4 w-4" />
      <div>
        <div className="text-xs font-bold leading-tight">{label}</div>
        <div className="text-[10px] opacity-80 leading-tight">{sub}</div>
      </div>
    </div>
  );
}
