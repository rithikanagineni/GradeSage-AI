import { LayoutDashboard, FileText, Inbox, BarChart3, Users, Settings, Sparkles, GraduationCap, LogOut, User } from 'lucide-react';
import type { View } from '../types';
import { cn } from '../utils/cn';
import { useAuth } from '../context/AuthContext';

const navItems: { id: View; label: string; icon: React.ElementType; badge?: number }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'assignments', label: 'Assignments', icon: FileText, badge: 3 },
  { id: 'submissions', label: 'Submissions', icon: Inbox, badge: 2 },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'students', label: 'Students', icon: Users },
  { id: 'profile', label: 'My Profile', icon: User },
  { id: 'settings', label: 'Agents & RAG', icon: Settings },
];

export function Sidebar({ current, onChange }: { current: View; onChange: (v: View) => void }) {
  const { user, signOut } = useAuth();
  const initials = user?.name.split(' ').map(n => n[0]).join('').slice(0, 2) || 'T';
  return (
    <aside className="flex h-screen w-64 flex-col border-r border-slate-200 bg-white">
      <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-100">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-md shadow-indigo-200">
          <GraduationCap className="h-5 w-5 text-white" />
        </div>
        <div>
          <div className="text-sm font-bold text-slate-900 leading-tight">GradeSage AI</div>
          <div className="text-[11px] text-slate-500 leading-tight">Assessment Automation</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group',
                active
                  ? 'bg-gradient-to-r from-indigo-50 to-violet-50 text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
            >
              <Icon
                className={cn(
                  'h-4 w-4 transition-colors',
                  active ? 'text-indigo-600' : 'text-slate-400 group-hover:text-slate-600'
                )}
                size={18}
              />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge !== undefined && (
                <span
                  className={cn(
                    'inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[10px] font-semibold',
                    active ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                  )}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 m-3 rounded-xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 text-white shadow-lg shadow-indigo-200">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-wide">Agents Active</span>
        </div>
        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between"><span className="text-indigo-100">OpenAI</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />Online</span></div>
          <div className="flex items-center justify-between"><span className="text-indigo-100">Claude</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />Online</span></div>
          <div className="flex items-center justify-between"><span className="text-indigo-100">RAG Index</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />1.2k docs</span></div>
        </div>
      </div>

      <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-3">
        <div className="h-9 w-9 rounded-full bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center text-white text-xs font-bold">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-slate-900 truncate">{user?.name}</div>
          <div className="text-xs text-slate-500 truncate">{user?.subject || 'Teacher'} · {user?.className || '—'}</div>
        </div>
        <button onClick={signOut} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400" title="Sign out">
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </aside>
  );
}
