import { useState } from 'react';
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  TrendingUp,
  User as UserIcon,
  LogOut,
  Clock,
  CheckCircle2,
  Send,
  Award,
  BookOpen,
  Sparkles,
  ChevronRight,
  ArrowRight,
  Edit3,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useAppData } from '../../context/AppDataContext';
import { cn } from '../../utils/cn';

type View = 'dashboard' | 'assignments' | 'feedback' | 'progress' | 'profile';

const NAV: { id: View; label: string; icon: any }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'assignments', label: 'My Assignments', icon: FileText },
  { id: 'feedback', label: 'Grades & Feedback', icon: MessageSquare },
  { id: 'progress', label: 'My Progress', icon: TrendingUp },
  { id: 'profile', label: 'Profile', icon: UserIcon },
];

export function StudentPortal() {
  const { user, signOut, updateUser } = useAuth();
  const { data } = useAppData();
  const [view, setView] = useState<View>('dashboard');

  const linkedStudent = data.students.find(
    s => s.email.toLowerCase() === user?.email.toLowerCase()
  );

  const studentSubs = data.submissions.filter(s => s.studentId === linkedStudent?.id);

  if (!user) return null;

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center shadow-md shadow-emerald-200">
            <BookOpen className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-slate-900 leading-tight">GradeSage AI</div>
            <div className="text-[11px] text-slate-500 leading-tight">Student portal</div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {NAV.map(n => {
            const Icon = n.icon;
            const active = view === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition',
                  active ? 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50'
                )}
              >
                <Icon className={cn('h-4 w-4', active ? 'text-emerald-600' : 'text-slate-400')} />
                <span>{n.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 m-3 rounded-xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 text-white shadow-lg shadow-emerald-200">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-4 w-4" />
            <span className="text-xs font-semibold uppercase tracking-wide">AI Graders Online</span>
          </div>
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center justify-between"><span className="text-emerald-100">OpenAI</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />Ready</span></div>
            <div className="flex items-center justify-between"><span className="text-emerald-100">Claude</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />Ready</span></div>
            <div className="flex items-center justify-between"><span className="text-emerald-100">RAG</span><span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />Ready</span></div>
          </div>
        </div>

        <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-3">
          <div className={cn('h-9 w-9 rounded-full flex items-center justify-center text-white text-xs font-bold', user.avatarColor || 'bg-slate-700')}>
            {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-slate-900 truncate">{user.name}</div>
            <div className="text-xs text-slate-500 truncate">Grade {user.grade || '—'} · {user.section || '—'}</div>
          </div>
          <button onClick={signOut} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400" title="Sign out">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </aside>

      <main className="flex-1 min-w-0 overflow-y-auto">
        {view === 'dashboard' && <StudentDashboard user={user} subs={studentSubs} onNavigate={setView} />}
        {view === 'assignments' && <StudentAssignments assignments={data.assignments} subs={studentSubs} onNavigate={setView} />}
        {view === 'feedback' && <StudentFeedback subs={studentSubs} assignments={data.assignments} />}
        {view === 'progress' && <StudentProgress subs={studentSubs} />}
        {view === 'profile' && <StudentProfile user={user} updateUser={updateUser} />}
      </main>
    </div>
  );
}

/* -------------------------- Dashboard -------------------------- */

function StudentDashboard({ user, subs, onNavigate }: any) {
  const graded = subs.filter((s: any) => s.status === 'graded');
  const avg = graded.length ? Math.round(graded.reduce((a: number, s: any) => a + (s.gradeResult?.percentage || 0), 0) / graded.length) : 0;

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-8 mb-6 text-white shadow-xl shadow-emerald-200">
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-5 w-5" />
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-100">
              {greeting()}, {user.name.split(' ')[0]}
            </span>
          </div>
          <h1 className="text-3xl font-bold leading-tight mb-2">Welcome to your learning space</h1>
          <p className="text-emerald-100 max-w-2xl mb-5">
            Submit your work to get detailed AI-powered feedback.
          </p>
          <div className="flex gap-3 flex-wrap">
            <button onClick={() => onNavigate('assignments')} className="inline-flex items-center gap-2 bg-white text-emerald-700 px-4 py-2 rounded-xl font-semibold text-sm hover:bg-emerald-50 transition">
              View assignments <ArrowRight className="h-4 w-4" />
            </button>
            <button onClick={() => onNavigate('feedback')} className="inline-flex items-center gap-2 bg-white/15 backdrop-blur border border-white/20 text-white px-4 py-2 rounded-xl font-semibold text-sm hover:bg-white/25 transition">
              Check feedback
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Award} label="Current average" value={avg ? `${avg}%` : '—'} color="emerald" />
        <StatCard icon={FileText} label="Submitted" value={subs.length} sub="assignments" color="indigo" />
        <StatCard icon={CheckCircle2} label="Graded" value={graded.length} color="teal" />
        <StatCard icon={Clock} label="Active" value={0} sub="due soon" color="amber" />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h3 className="font-bold text-slate-900 mb-3">Get started</h3>
        <p className="text-sm text-slate-600">No assignments yet. Your teacher will add them soon.</p>
        <button onClick={() => onNavigate('assignments')} className="mt-4 text-sm font-semibold text-emerald-600 hover:text-emerald-700">
          Go to Assignments →
        </button>
      </div>
    </div>
  );
}

/* -------------------------- Assignments -------------------------- */

function StudentAssignments({ assignments, subs, onNavigate }: any) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { addSubmission } = useAppData();

  const handleSubmit = (assignmentId: string, content: string) => {
    const newSub: any = {
      id: `sub-${Date.now()}`,
      assignmentId,
      studentId: 'current',
      submittedAt: new Date().toISOString(),
      content,
      status: 'graded',
      gradeResult: {
        submissionId: `sub-${Date.now()}`,
        overallScore: 82,
        maxScore: 100,
        percentage: 82,
        gradeLetter: 'B-',
        completedAt: new Date().toISOString(),
        confidence: 0.88,
        agentBreakdown: { openai: { role: '', score: 82, observations: [], ms: 0 }, claude: { role: '', score: 82, observations: [], ms: 0 }, rag: { role: '', matchedStandards: [], alignment: 0.9, ms: 0 } },
        feedback: [],
        summaryStrengths: ['Good structure'],
        summaryAreasForGrowth: ['Add more examples'],
        nextSteps: ['Revise conclusion'],
        holisticComment: 'Good work. Keep developing your ideas.',
        hallucinationCheck: { passed: true, score: 0.95, notes: '' },
        humanReviewRecommended: false,
      },
    };
    addSubmission(newSub);
    onNavigate('feedback');
  };

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">My Assignments</h1>
      </div>

      {assignments.length === 0 ? (
        <div className="bg-white rounded-2xl border p-10 text-center">
          <FileText className="h-12 w-12 mx-auto text-slate-300 mb-3" />
          <h3 className="font-bold text-slate-900">No assignments yet</h3>
          <p className="text-sm text-slate-500 mt-1">Your teacher will create assignments here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {assignments.map((a: any) => {
            const sub = subs.find((s: any) => s.assignmentId === a.id);
            const isOpen = selectedId === a.id;
            return (
              <div key={a.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <button onClick={() => setSelectedId(isOpen ? null : a.id)} className="w-full text-left p-5 flex items-start gap-4 hover:bg-slate-50 transition">
                  <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white shrink-0">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-slate-900">{a.title}</h3>
                    <p className="text-sm text-slate-600 mt-1">{a.description}</p>
                  </div>
                  <ChevronRight className={cn('h-5 w-5 text-slate-300 shrink-0 transition-transform', isOpen && 'rotate-90 text-emerald-500')} />
                </button>

                {isOpen && (
                  <div className="border-t border-slate-100 p-5 bg-slate-50">
                    {!sub ? (
                      <div>
                        <textarea id={`ta-${a.id}`} placeholder="Paste your submission here..." className="w-full min-h-[160px] border border-slate-200 rounded-xl p-4 text-sm" />
                        <button
                          onClick={() => {
                            const ta = document.getElementById(`ta-${a.id}`) as HTMLTextAreaElement;
                            if (ta && ta.value.trim().length > 5) handleSubmit(a.id, ta.value);
                          }}
                          className="mt-3 px-5 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold"
                        >
                          Submit for feedback
                        </button>
                      </div>
                    ) : (
                      <div className="text-sm text-emerald-600 font-medium">Already submitted. Check feedback.</div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* -------------------------- Feedback -------------------------- */

function StudentFeedback({ subs, assignments }: any) {
  const [openId, setOpenId] = useState<string | null>(subs[0]?.id || null);
  const open = subs.find((s: any) => s.id === openId);

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">Grades &amp; Feedback</h1>

      {subs.length === 0 ? (
        <div className="bg-white rounded-2xl border p-10 text-center text-slate-500">No graded submissions yet.</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-1 space-y-3">
            {subs.filter((s: any) => s.status === 'graded').map((sub: any) => {
              const a = assignments.find((x: any) => x.id === sub.assignmentId);
              return (
                <button key={sub.id} onClick={() => setOpenId(sub.id)} className={cn('w-full text-left p-4 rounded-2xl border transition', openId === sub.id ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-200')}>
                  <div className="font-semibold text-sm">{a?.title || 'Assignment'}</div>
                  <div className="text-xs text-slate-500 mt-1">{sub.gradeResult?.percentage}% • {sub.gradeResult?.gradeLetter}</div>
                </button>
              );
            })}
          </div>
          <div className="lg:col-span-2">
            {open ? (
              <div className="bg-white rounded-2xl border p-6">
                <div className="font-semibold mb-2">{assignments.find((a: any) => a.id === open.assignmentId)?.title}</div>
                <div className="text-sm text-slate-700">{open.gradeResult?.holisticComment || 'Feedback available.'}</div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------- Progress -------------------------- */

function StudentProgress({ subs }: any) {
  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <h1 className="text-2xl font-bold text-slate-900 mb-6">My Progress</h1>
      <div className="bg-white rounded-2xl border p-10 text-center text-slate-500">
        Progress data will appear here once you have submissions.
      </div>
    </div>
  );
}

/* -------------------------- Profile with Edit -------------------------- */

function StudentProfile({ user, updateUser }: any) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    name: user.name || '',
    grade: user.grade || '',
    section: user.section || '',
    phone: user.phone || '',
  });

  const save = () => {
    updateUser(form);
    setEditing(false);
  };

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
        {!editing ? (
          <button onClick={() => setEditing(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold">
            <Edit3 className="h-4 w-4" /> Edit
          </button>
        ) : (
          <div className="flex gap-2">
            <button onClick={() => setEditing(false)} className="px-4 py-2 rounded-xl border text-sm">Cancel</button>
            <button onClick={save} className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold">Save</button>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-8">
        <div className="flex items-start gap-4 mb-6">
          <div className={cn('h-16 w-16 rounded-2xl flex items-center justify-center text-white font-bold text-xl', user.avatarColor || 'bg-emerald-500')}>
            {user.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
          </div>
          <div className="flex-1">
            {!editing ? (
              <>
                <h2 className="font-bold text-2xl text-slate-900">{user.name}</h2>
                <p className="text-slate-500">{user.email}</p>
              </>
            ) : (
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="text-2xl font-bold border border-slate-300 rounded-lg px-3 py-1 w-full" />
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div>
            <div className="text-xs text-slate-500 uppercase font-semibold tracking-wider mb-1">Grade</div>
            {!editing ? <div className="font-medium">{user.grade || '—'}</div> : <input value={form.grade} onChange={e => setForm({ ...form, grade: e.target.value })} className="border border-slate-300 rounded-lg px-3 py-2 w-full" />}
          </div>
          <div>
            <div className="text-xs text-slate-500 uppercase font-semibold tracking-wider mb-1">Section</div>
            {!editing ? <div className="font-medium">{user.section || '—'}</div> : <input value={form.section} onChange={e => setForm({ ...form, section: e.target.value })} className="border border-slate-300 rounded-lg px-3 py-2 w-full" />}
          </div>
          <div>
            <div className="text-xs text-slate-500 uppercase font-semibold tracking-wider mb-1">Phone</div>
            {!editing ? <div className="font-medium">{user.phone || '—'}</div> : <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="border border-slate-300 rounded-lg px-3 py-2 w-full" />}
          </div>
          <div>
            <div className="text-xs text-slate-500 uppercase font-semibold tracking-wider mb-1">Student ID</div>
            <div className="font-medium">{user.studentId || '—'}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Helpers */

function StatCard({ icon: Icon, label, value, sub, color }: any) {
  const colorMap: any = { emerald: 'bg-emerald-100 text-emerald-600', indigo: 'bg-indigo-100 text-indigo-600', teal: 'bg-teal-100 text-teal-600', amber: 'bg-amber-100 text-amber-600' };
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5">
      <div className="flex justify-between">
        <div>
          <div className="text-xs text-slate-500 uppercase tracking-wide font-medium">{label}</div>
          <div className="text-2xl font-bold text-slate-900 mt-1">{value}</div>
          {sub && <div className="text-xs text-slate-500">{sub}</div>}
        </div>
        <div className={cn('h-10 w-10 rounded-xl flex items-center justify-center', colorMap[color])}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}
