import { useState } from 'react';
import { Plus, FileText, Calendar, BookOpen, CheckSquare, MoreVertical, Edit3, Copy, Sparkles, Users } from 'lucide-react';
import type { Assignment } from '../types';
import { cn } from '../utils/cn';
import { useToast } from '../context/ToastContext';
import { useAppData } from '../context/AppDataContext';
import { useAuth } from '../context/AuthContext';

export function Assignments() {
  const toast = useToast();
  const { user } = useAuth();
  const { data, addAssignment } = useAppData();
  const [showNew, setShowNew] = useState(false);
  const [selectedType, setSelectedType] = useState<Assignment['type'] | 'all'>('all');

  const assignments = data.assignments;
  const submissions = data.submissions;
  const filtered = selectedType === 'all' ? assignments : assignments.filter(a => a.type === selectedType);

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Assignments</h1>
          <p className="text-slate-500 text-sm">Create assignments with AI-powered rubric suggestions and standards tagging.</p>
        </div>
        <button onClick={() => setShowNew(true)} className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-md shadow-indigo-200 hover:shadow-lg hover:shadow-indigo-300 transition">
          <Plus className="h-4 w-4" /> New Assignment
        </button>
      </div>

      <div className="flex gap-2 mb-6 flex-wrap">
        {(['all', 'essay', 'short_answer', 'problem_set', 'quiz', 'project'] as const).map(t => (
          <button
            key={t}
            onClick={() => setSelectedType(t)}
            className={cn(
              'px-3.5 py-1.5 rounded-full text-xs font-semibold transition',
              selectedType === t ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:border-indigo-300'
            )}
          >
            {t.replace('_', ' ')}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center mb-6">
          <FileText className="h-12 w-12 mx-auto text-slate-300 mb-3" />
          <h3 className="font-semibold text-slate-900">No assignments yet</h3>
          <p className="text-sm text-slate-500 mt-1">Click "New Assignment" to create your first one.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map(a => {
            const subCount = submissions.filter(s => s.assignmentId === a.id).length;
            const gradedCount = submissions.filter(s => s.assignmentId === a.id && s.status === 'graded').length;
            const statusColor = a.status === 'active' ? 'bg-emerald-100 text-emerald-700' : a.status === 'closed' ? 'bg-slate-100 text-slate-600' : 'bg-amber-100 text-amber-700';
            const typeColors: Record<string, string> = { essay: 'from-rose-500 to-pink-500', short_answer: 'from-sky-500 to-cyan-500', problem_set: 'from-emerald-500 to-teal-500', quiz: 'from-amber-500 to-orange-500', project: 'from-violet-500 to-fuchsia-500' };
            return (
              <div key={a.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg transition-all overflow-hidden group">
                <div className={cn('h-1.5 bg-gradient-to-r', typeColors[a.type])} />
                <div className="p-5">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{a.subject}</span>
                        <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full', statusColor)}>{a.status}</span>
                      </div>
                      <h3 className="font-bold text-slate-900 leading-tight line-clamp-2">{a.title}</h3>
                    </div>
                    <button onClick={() => toast('Assignment options', 'info')} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 shrink-0">
                      <MoreVertical className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-4 leading-relaxed">{a.description}</p>
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <MiniStat icon={Calendar} label="Due" value={new Date(a.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} />
                    <MiniStat icon={Users} label="Subs" value={`${gradedCount}/${subCount}`} />
                    <MiniStat icon={FileText} label="Points" value={a.totalPoints.toString()} />
                  </div>
                  <div className="flex items-center gap-2 flex-wrap mb-4">
                    {a.standardsTags?.slice(0, 3).map(t => (
                      <span key={t} className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md font-mono font-medium">{t}</span>
                    ))}
                  </div>
                  <div className="flex gap-2 pt-3 border-t border-slate-100">
                    <button onClick={() => toast('Go to Submissions to grade', 'info')} className="flex-1 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 py-2 rounded-lg transition">Grade</button>
                    <button onClick={() => toast('Edit — coming soon', 'info')} className="text-sm font-medium text-slate-600 hover:bg-slate-50 p-2 rounded-lg transition"><Edit3 className="h-4 w-4" /></button>
                    <button onClick={() => toast('Copied', 'success')} className="text-sm font-medium text-slate-600 hover:bg-slate-50 p-2 rounded-lg transition"><Copy className="h-4 w-4" /></button>
                  </div>
                </div>
              </div>
            );
          })}
          <button onClick={() => setShowNew(true)} className="border-2 border-dashed border-slate-300 rounded-2xl p-6 flex flex-col items-center justify-center gap-3 text-slate-500 hover:border-indigo-400 hover:text-indigo-600 hover:bg-indigo-50/30 transition min-h-[280px]">
            <div className="h-12 w-12 rounded-xl bg-slate-100 flex items-center justify-center">
              <Plus className="h-6 w-6" />
            </div>
            <div className="text-center">
              <div className="font-semibold">Create new assignment</div>
              <div className="text-xs">AI-assisted rubric & standards tagging</div>
            </div>
          </button>
        </div>
      )}

      {showNew && <NewAssignmentModal onClose={() => setShowNew(false)} user={user} addAssignment={addAssignment} toast={toast} />}
    </div>
  );
}

function MiniStat({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="text-center bg-slate-50 rounded-lg py-2">
      <Icon className="h-3.5 w-3.5 text-slate-400 mx-auto mb-0.5" />
      <div className="text-[10px] text-slate-500 uppercase tracking-wide font-medium">{label}</div>
      <div className="text-xs font-bold text-slate-900">{value}</div>
    </div>
  );
}

/* ---------- New Assignment Modal ---------- */

function NewAssignmentModal({ onClose, user, addAssignment, toast }: any) {
  const [prompt, setPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [selType, setSelType] = useState<string>('essay');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('');
  const [points, setPoints] = useState(100);

  const handleGenerate = () => {
    setGenerating(true);
    setTimeout(() => {
      setGenerating(false);
      setGenerated(true);
      // Derive title from prompt
      setTitle(prompt.slice(0, 60) + (prompt.length > 60 ? '…' : ''));
      setSubject(user?.subject || 'General');
      setPoints(selType === 'quiz' ? 25 : selType === 'problem_set' ? 50 : 100);
      setDescription(prompt);
    }, 2000);
  };

  const handleCreate = () => {
    const newAssignment: any = {
      id: `a-${Date.now()}`,
      title: title || prompt.slice(0, 50),
      subject: subject || user?.subject || 'General',
      description: description || prompt,
      type: selType as Assignment['type'],
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
      totalPoints: points,
      status: 'active',
      standardsTags: generated ? ['RL.9-10.1', 'RL.9-10.2', 'W.9-10.1', 'W.9-10.9'] : [],
      rubric: generated ? [
        { id: `r-detail-${Date.now()}-0`, criterion: 'Thesis & Argument', maxPoints: Math.round(points * 0.25), weight: 0.25, description: 'Clear, arguable thesis with sustained argument.' },
        { id: `r-detail-${Date.now()}-1`, criterion: 'Evidence & Citations', maxPoints: Math.round(points * 0.25), weight: 0.25, description: 'Use of evidence and correct citation format.' },
        { id: `r-detail-${Date.now()}-2`, criterion: 'Analysis & Depth', maxPoints: Math.round(points * 0.20), weight: 0.20, description: 'Interpretive depth linking evidence to argument.' },
        { id: `r-detail-${Date.now()}-3`, criterion: 'Organization', maxPoints: Math.round(points * 0.15), weight: 0.15, description: 'Logical structure with clear intro and conclusion.' },
        { id: `r-detail-${Date.now()}-4`, criterion: 'Style & Mechanics', maxPoints: Math.round(points * 0.15), weight: 0.15, description: 'Grammar, spelling, and academic tone.' },
      ] : [],
      createdAt: new Date().toISOString(),
    };
    addAssignment(newAssignment);
    toast(`Assignment "${newAssignment.title}" created successfully`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-lg">New Assignment</h2>
              <p className="text-xs text-slate-500">AI-assisted creation with rubric and standards</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-2xl leading-none">×</button>
        </div>

        <div className="p-6">
          <div className="mb-4">
            <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-2 block">What do you want to assign?</label>
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder='e.g., "A 500-word essay for 10th grade English analyzing symbolism in Chapter 5 of To Kill a Mockingbird, aligned to RL.9-10.2"'
              className="w-full p-3 border border-slate-200 rounded-xl text-sm min-h-[100px] focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            {(['essay', 'problem_set', 'quiz'] as const).map(t => (
              <button
                key={t}
                onClick={() => setSelType(t)}
                className={cn(
                  'p-3 border rounded-xl text-sm font-medium transition capitalize',
                  selType === t ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-slate-200 hover:border-indigo-400 hover:bg-indigo-50'
                )}
              >
                {t.replace('_', ' ')}
              </button>
            ))}
          </div>

          {!generated && (
            <button
              onClick={handleGenerate}
              disabled={!prompt || generating}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold text-sm disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {generating ? (
                <><span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Agents drafting rubric, pulling standards, generating prompt…</>
              ) : (
                <><Sparkles className="h-4 w-4" /> Generate with AI</>
              )}
            </button>
          )}

          {generated && (
            <div className="space-y-4 border-t border-slate-100 pt-5">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-3">
                <CheckSquare className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-sm text-emerald-900">
                  <b>Drafted.</b> You can edit the details below before creating.
                </div>
              </div>
              <Field label="Title">
                <input value={title} onChange={e => setTitle(e.target.value)} className="w-full p-2.5 border border-slate-200 rounded-lg text-sm" />
              </Field>
              <Field label="Subject">
                <input value={subject} onChange={e => setSubject(e.target.value)} className="w-full p-2.5 border border-slate-200 rounded-lg text-sm" />
              </Field>
              <Field label="Description">
                <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full p-2.5 border border-slate-200 rounded-lg text-sm min-h-[80px]" />
              </Field>
              <Field label="Total points">
                <input type="number" value={points} onChange={e => setPoints(Number(e.target.value))} className="w-32 p-2.5 border border-slate-200 rounded-lg text-sm" />
              </Field>
              <div>
                <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1 block">Rubric (AI-generated)</label>
                <div className="space-y-2">
                  {['Thesis & Argument', 'Evidence & Citations', 'Analysis & Depth', 'Organization', 'Style & Mechanics'].map((r, i) => {
                    const maxPts = Math.round(points * [0.25, 0.25, 0.20, 0.15, 0.15][i]);
                    return (
                      <div key={r} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg text-sm">
                        <span className="text-slate-700">{r}</span>
                        <span className="text-xs text-slate-500">{maxPts} pts</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1 block">Auto-matched standards (RAG)</label>
                <div className="flex flex-wrap gap-2">
                  {['RL.9-10.1', 'RL.9-10.2', 'W.9-10.1', 'W.9-10.9'].map(s => (
                    <span key={s} className="text-xs bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md font-mono font-semibold">{s}</span>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => { setGenerated(false); setTimeout(() => handleGenerate(), 500); }} className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-semibold text-sm hover:bg-slate-200 transition">Regenerate</button>
                <button onClick={handleCreate} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold text-sm">Create assignment</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1 block">{label}</label>
      {children}
    </div>
  );
}
