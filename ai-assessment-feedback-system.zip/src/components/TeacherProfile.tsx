import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAppData } from '../context/AppDataContext';
import { Edit3, Save, Mail, Phone, BookOpen } from 'lucide-react';

export function TeacherProfile() {
  const { user, updateUser } = useAuth();
  const { data } = useAppData();
  const [editing, setEditing] = useState(false);

  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    subject: user?.subject || '',
    className: user?.className || '',
    phone: user?.phone || '',
  });

  if (!user) return null;

  const handleSave = () => {
    updateUser(form);
    setEditing(false);
  };

  const myAssignments = data.assignments.filter(a => a.subject?.toLowerCase().includes(user.subject?.toLowerCase() || ''));
  const myStudents = data.students.length;

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
        {!editing ? (
          <button
            onClick={() => setEditing(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700"
          >
            <Edit3 className="h-4 w-4" /> Edit Profile
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => setEditing(false)}
              className="px-4 py-2 rounded-xl border text-sm font-semibold hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700"
            >
              <Save className="h-4 w-4" /> Save Changes
            </button>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-8">
        <div className="flex items-start gap-4 mb-8">
          <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center text-white text-2xl font-bold">
            {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
          </div>
          <div className="flex-1">
            {!editing ? (
              <>
                <h2 className="font-bold text-2xl text-slate-900">{user.name}</h2>
                <div className="flex items-center gap-1.5 text-slate-500 mt-1">
                  <Mail className="h-4 w-4" /> {user.email}
                </div>
              </>
            ) : (
              <div className="space-y-3">
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full text-2xl font-bold border border-slate-300 rounded-xl px-4 py-2"
                  placeholder="Full name"
                />
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full border border-slate-300 rounded-xl px-4 py-2 text-sm"
                  placeholder="Email"
                />
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 text-sm">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
              <BookOpen className="h-3.5 w-3.5" /> Subject
            </div>
            {!editing ? (
              <div className="font-medium text-slate-900 text-base">{user.subject || '—'}</div>
            ) : (
              <input
                value={form.subject}
                onChange={e => setForm({ ...form, subject: e.target.value })}
                className="w-full border border-slate-300 rounded-xl px-3 py-2"
              />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
              Class / Section
            </div>
            {!editing ? (
              <div className="font-medium text-slate-900 text-base">{user.className || '—'}</div>
            ) : (
              <input
                value={form.className}
                onChange={e => setForm({ ...form, className: e.target.value })}
                className="w-full border border-slate-300 rounded-xl px-3 py-2"
              />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
              <Phone className="h-3.5 w-3.5" /> Phone
            </div>
            {!editing ? (
              <div className="font-medium text-slate-900 text-base">{user.phone || '—'}</div>
            ) : (
              <input
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full border border-slate-300 rounded-xl px-3 py-2"
              />
            )}
          </div>

          <div>
            <div className="text-xs uppercase tracking-wider font-semibold text-slate-500 mb-1">Role</div>
            <div className="font-medium text-slate-900 text-base capitalize">{user.role}</div>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="text-xs text-slate-500">Assignments Created</div>
          <div className="text-3xl font-bold text-indigo-600 mt-1">{myAssignments.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="text-xs text-slate-500">Students in Class</div>
          <div className="text-3xl font-bold text-indigo-600 mt-1">{myStudents}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="text-xs text-slate-500">Submissions Received</div>
          <div className="text-3xl font-bold text-indigo-600 mt-1">{data.submissions.length}</div>
        </div>
      </div>
    </div>
  );
}
