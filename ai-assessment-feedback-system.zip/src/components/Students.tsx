import { useState } from 'react';
import { Search, Mail, TrendingUp, TrendingDown, MessageSquare, Award, Target, ChevronRight, X, Send, Phone, Paperclip, Smile } from 'lucide-react';
import type { Student } from '../types';
import { cn } from '../utils/cn';
import { useToast } from '../context/ToastContext';
import { useAppData } from '../context/AppDataContext';

export function Students() {
  const toast = useToast();
  const { data, addStudent } = useAppData();
  const { students, submissions } = data;
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(students[0]?.id || null);
  const [emailFor, setEmailFor] = useState<Student | null>(null);
  const [messageFor, setMessageFor] = useState<Student | null>(null);
  const [showAddStudent, setShowAddStudent] = useState(false);

  const filtered = students.filter(s => s.name.toLowerCase().includes(query.toLowerCase()));
  const selected = students.find(s => s.id === selectedId) || null;
  const studentSubs = submissions.filter(s => s.studentId === selectedId);

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Students</h1>
          <p className="text-slate-500 text-sm">{students.length} students enrolled</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search…" className="pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-white text-sm w-48 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none" />
          </div>
          <button onClick={() => setShowAddStudent(true)} className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700">
            + Add student
          </button>
        </div>
      </div>

      {students.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
          <Users className="h-12 w-12 mx-auto text-slate-300 mb-3" />
          <h3 className="font-bold text-slate-900 text-lg">No students yet</h3>
          <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">Add your first student to get started.</p>
          <button onClick={() => setShowAddStudent(true)} className="mt-4 px-5 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold">+ Add Student</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="divide-y divide-slate-100">
              {filtered.map(s => {
                const active = s.id === selectedId;
                const trend = (s.averageScore || 0) >= 80;
                return (
                  <button key={s.id} onClick={() => setSelectedId(s.id)} className={cn('w-full flex items-center gap-3 p-4 text-left transition', active ? 'bg-indigo-50' : 'hover:bg-slate-50')}>
                    <div className={cn('h-11 w-11 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0', s.avatarColor)}>
                      {s.name.split(' ').map((n: string) => n[0]).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-semibold text-slate-900 text-sm truncate">{s.name}</div>
                        <div className={cn('text-sm font-bold shrink-0', trend ? 'text-emerald-600' : 'text-amber-600')}>{s.averageScore}%</div>
                      </div>
                      <div className="flex items-center justify-between gap-2 mt-0.5">
                        <div className="text-xs text-slate-500 truncate">{s.className} · {s.submissionsCount} subs</div>
                        {trend ? <TrendingUp className="h-3 w-3 text-emerald-500 shrink-0" /> : <TrendingDown className="h-3 w-3 text-amber-500 shrink-0" />}
                      </div>
                    </div>
                    <ChevronRight className={cn('h-4 w-4 shrink-0', active ? 'text-indigo-500' : 'text-slate-300')} />
                  </button>
                );
              })}
            </div>
          </div>
          {selected && (
            <div className="lg:col-span-3 space-y-5">
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <div className="flex items-start gap-4">
                  <div className={cn('h-16 w-16 rounded-2xl flex items-center justify-center text-white font-bold text-xl', selected.avatarColor)}>
                    {selected.name.split(' ').map((n: string) => n[0]).join('')}
                  </div>
                  <div className="flex-1">
                    <h2 className="font-bold text-slate-900 text-xl">{selected.name}</h2>
                    <div className="text-sm text-slate-500 flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> {selected.email}</div>
                    {selected.phone && <div className="text-sm text-slate-500 flex items-center gap-1.5 mt-0.5"><Phone className="h-3.5 w-3.5" /> {selected.phone}</div>}
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full font-medium">Grade {selected.grade}</span>
                      <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full font-medium">Class {selected.className}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setEmailFor(selected)} className="px-3 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold"><Mail className="h-4 w-4" /></button>
                    <button onClick={() => setMessageFor(selected)} className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold"><MessageSquare className="h-4 w-4" /></button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-6">
                  <div className="p-3 rounded-xl bg-indigo-50 text-center"><div className="text-2xl font-bold text-indigo-700">{selected.averageScore || '—'}%</div><div className="text-[10px] text-indigo-600 uppercase font-semibold">Average</div></div>
                  <div className="p-3 rounded-xl bg-violet-50 text-center"><div className="text-2xl font-bold text-violet-700">{selected.submissionsCount || 0}</div><div className="text-[10px] text-violet-600 uppercase font-semibold">Submissions</div></div>
                  <div className="p-3 rounded-xl bg-emerald-50 text-center"><div className="text-2xl font-bold text-emerald-700">{0}%</div><div className="text-[10px] text-emerald-600 uppercase font-semibold">On-time</div></div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {showAddStudent && <AddStudentModal onClose={() => setShowAddStudent(false)} addStudent={addStudent} toast={toast} />}
      {emailFor && <EmailModal student={emailFor} onClose={() => setEmailFor(null)} />}
      {messageFor && <MessageModal student={messageFor} onClose={() => setMessageFor(null)} />}
    </div>
  );
}

/* -------------------------------- Add Student -------------------------------- */

function AddStudentModal({ onClose, addStudent, toast }: any) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [grade, setGrade] = useState('10');
  const [className, setClassName] = useState('10-A');
  const [phone, setPhone] = useState('');

  const handleAdd = () => {
    if (!name || !email) return toast('Name and email are required', 'error');
    const newStudent: Student = {
      id: `s-${Date.now()}`,
      name, email, phone,
      grade, className,
      avatarColor: ['bg-rose-500', 'bg-sky-500', 'bg-amber-500', 'bg-emerald-500', 'bg-violet-500'][Math.floor(Math.random() * 5)],
      averageScore: 0,
      submissionsCount: 0,
      strengths: [], growthAreas: [],
    };
    addStudent(newStudent);
    toast(`Added ${name}`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-lg">Add student</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="h-5 w-5" /></button>
        </div>
        <div className="p-5 space-y-3">
          <Field label="Full name"><input value={name} onChange={e => setName(e.target.value)} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Email"><input value={email} onChange={e => setEmail(e.target.value)} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Grade"><select value={grade} onChange={e => setGrade(e.target.value)} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white">{['6','7','8','9','10','11','12'].map(g => <option key={g}>{g}</option>)}</select></Field>
            <Field label="Class"><input value={className} onChange={e => setClassName(e.target.value)} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" /></Field>
          </div>
          <Field label="Phone (optional)"><input value={phone} onChange={e => setPhone(e.target.value)} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" /></Field>
        </div>
        <div className="p-5 border-t border-slate-100 flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-xl border text-sm">Cancel</button>
          <button onClick={handleAdd} className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold">Add student</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: any) {
  return <div><label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1 block">{label}</label>{children}</div>;
}

/* -------------------------------- Email -------------------------------- */

function EmailModal({ student, onClose }: any) {
  const toast = useToast();
  const [subject, setSubject] = useState(`Update on your progress — ${student.name.split(' ')[0]}`);
  const [body, setBody] = useState(`Hi ${student.name.split(' ')[0]},\n\nJust a quick update on your recent work.\n\nBest,\nTeacher`);
  const send = () => { toast(`Email sent to ${student.email}`, 'success'); onClose(); };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b flex items-center justify-between">
          <div className="flex items-center gap-3"><div className="h-10 w-10 rounded-xl bg-indigo-500 flex items-center justify-center"><Mail className="h-5 w-5 text-white" /></div><div><h2 className="font-bold">New email</h2><p className="text-xs text-slate-500">To: {student.email}</p></div></div>
          <button onClick={onClose}><X className="h-5 w-5 text-slate-400" /></button>
        </div>
        <div className="px-5 py-3 border-b"><input value={subject} onChange={e => setSubject(e.target.value)} className="w-full text-sm outline-none" /></div>
        <div className="flex-1 p-5"><textarea value={body} onChange={e => setBody(e.target.value)} className="w-full min-h-[200px] text-sm outline-none resize-none" /></div>
        <div className="p-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 border rounded-xl text-sm">Discard</button>
          <button onClick={send} className="px-4 py-2 bg-indigo-600 text-white text-sm rounded-xl font-semibold flex items-center gap-1.5"><Send className="h-4 w-4" /> Send</button>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- Message -------------------------------- */

function MessageModal({ student, onClose }: any) {
  const toast = useToast();
  const [text, setText] = useState('');
  const send = () => { if (!text.trim()) return; toast(`SMS sent to ${student.phone}`, 'success'); onClose(); };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[85vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white flex items-center justify-between">
          <div className="flex items-center gap-3"><div className={cn('h-10 w-10 rounded-full bg-white/20 flex items-center justify-center font-bold')}>{student.name.split(' ').map((n: string) => n[0]).join('')}</div><div><h2 className="font-bold">{student.name}</h2><p className="text-[11px] text-emerald-50"><Phone className="h-3 w-3 inline" /> {student.phone}</p></div></div>
          <button onClick={onClose}><X className="h-5 w-5 text-white/80" /></button>
        </div>
        <div className="flex-1 p-4 bg-slate-50 min-h-[200px] text-center text-sm text-slate-400 flex items-center justify-center">No messages yet</div>
        <div className="p-3 border-t flex items-end gap-2">
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Type a message…" rows={1} className="flex-1 resize-none border border-slate-200 rounded-xl px-3 py-2 text-sm" />
          <button onClick={send} disabled={!text.trim()} className="h-10 w-10 rounded-xl bg-emerald-600 text-white disabled:opacity-50"><Send className="h-4 w-4" /></button>
        </div>
      </div>
    </div>
  );
}

function Users({ className }: any) { return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>; }
