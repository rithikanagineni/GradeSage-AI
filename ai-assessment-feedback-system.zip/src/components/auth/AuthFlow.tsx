import { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  ArrowRight,
  Mail,
  Lock,
  User as UserIcon,
  Sparkles,
  CheckCircle2,
  Zap,
  Clock,
  Target,
  MessageSquare,
  ChevronLeft,
  AlertCircle,
  Shield,
  Brain,
  Database,
} from 'lucide-react';
import { useAuth, type Role } from '../../context/AuthContext';
import { cn } from '../../utils/cn';

export function AuthFlow() {
  const [stage, setStage] = useState<'landing' | 'auth'>('landing');
  const [role, setRole] = useState<Role | null>(null);

  if (stage === 'landing' || !role) {
    return <LandingPage onChoose={(r) => { setRole(r); setStage('auth'); }} />;
  }
  return (
    <AuthScreen
      role={role}
      onBack={() => { setStage('landing'); setRole(null); }}
    />
  );
}

/* ============================== LANDING PAGE ============================== */

function LandingPage({ onChoose }: { onChoose: (r: Role) => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-violet-50 relative overflow-hidden">
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-300/30 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-fuchsia-300/30 rounded-full blur-3xl" />

      <div className="relative max-w-6xl mx-auto px-6 py-10">
        {/* Header */}
        <header className="flex items-center justify-between mb-16">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-200">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="font-bold text-slate-900 text-lg leading-tight">GradeSage AI</div>
              <div className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">Assessment Automation</div>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs">
            <span className="flex items-center gap-1.5 bg-white/70 backdrop-blur px-2.5 py-1 rounded-full border border-slate-200 text-slate-600 font-medium">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> Multi-agent AI
            </span>
          </div>
        </header>

        {/* Hero */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 bg-white border border-indigo-200 px-3 py-1.5 rounded-full text-xs font-semibold text-indigo-700 mb-6 shadow-sm">
            <Sparkles className="h-3.5 w-3.5" />
            OpenAI · Claude · RAG-powered assessment
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold text-slate-900 mb-4 leading-[1.05] tracking-tight">
            Assessment that teaches,<br />
            <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
              not just grades.
            </span>
          </h1>
          <p className="text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
            Teachers spend up to <b className="text-slate-900">40% of their time</b> on grading and feedback. GradeSage's multi-agent AI delivers criterion-level scores, holistic feedback, and standards-aligned reports — so you can focus on students.
          </p>
        </div>

        {/* Feature strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto mb-14">
          {[
            { icon: Brain, label: 'Rubric scoring', color: 'text-emerald-600 bg-emerald-100' },
            { icon: MessageSquare, label: 'Holistic feedback', color: 'text-amber-600 bg-amber-100' },
            { icon: Database, label: 'Standards alignment', color: 'text-sky-600 bg-sky-100' },
            { icon: Clock, label: '75% faster', color: 'text-violet-600 bg-violet-100' },
          ].map((f) => (
            <div key={f.label} className="bg-white/70 backdrop-blur border border-slate-200 rounded-xl px-3 py-2.5 flex items-center gap-2 shadow-sm">
              <div className={cn('h-7 w-7 rounded-lg flex items-center justify-center', f.color)}>
                <f.icon className="h-3.5 w-3.5" />
              </div>
              <span className="text-xs font-semibold text-slate-700">{f.label}</span>
            </div>
          ))}
        </div>

        {/* Role selection */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Get started</div>
            <h2 className="text-2xl font-bold text-slate-900">How will you use GradeSage?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <RoleCard
              role="teacher"
              onClick={() => onChoose('teacher')}
              title="I'm a Teacher"
              subtitle="Create assignments, grade with AI agents, and track class mastery"
              gradient="from-indigo-500 via-violet-500 to-fuchsia-500"
              features={[
                'Auto-grade submissions in ~47 seconds',
                'Multi-agent rubric scoring (OpenAI + Claude + RAG)',
                'Standards-aligned progress reports',
                'Human-in-the-loop override for edge cases',
              ]}
              note="Requires a school / college email"
              icon={GraduationCap}
            />
            <RoleCard
              role="student"
              onClick={() => onChoose('student')}
              title="I'm a Student"
              subtitle="Submit work, get instant AI feedback, and grow your skills"
              gradient="from-emerald-500 via-teal-500 to-cyan-500"
              features={[
                'Receive feedback within seconds',
                'Criterion-level rubric scores',
                'Personalized strengths & growth areas',
                'Track your progress over time',
              ]}
              note="Open to everyone — any email works"
              icon={BookOpen}
            />
          </div>
        </div>

        <footer className="text-center mt-14 text-xs text-slate-500">
          Built with OpenAI · Claude · RAG · React · Tailwind
        </footer>
      </div>
    </div>
  );
}

/* ================================ ROLE CARD =============================== */

function RoleCard({ role, onClick, title, subtitle, gradient, features, note, icon: Icon }: {
  role: Role;
  onClick: () => void;
  title: string;
  subtitle: string;
  gradient: string;
  features: string[];
  note: string;
  icon: any;
}) {
  return (
    <button
      onClick={onClick}
      className="group text-left bg-white rounded-3xl border border-slate-200 p-7 shadow-sm hover:shadow-2xl hover:shadow-indigo-200 hover:-translate-y-1 transition-all relative overflow-hidden"
    >
      <div className={cn('absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r', gradient)} />
      <div className="flex items-start justify-between mb-5">
        <div className={cn('h-14 w-14 rounded-2xl bg-gradient-to-br flex items-center justify-center shadow-lg', gradient)}>
          <Icon className="h-7 w-7 text-white" />
        </div>
        <ArrowRight className="h-5 w-5 text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
      </div>
      <h3 className="text-2xl font-bold text-slate-900 mb-1.5">{title}</h3>
      <p className="text-sm text-slate-600 mb-4 leading-relaxed">{subtitle}</p>
      <ul className="space-y-2 mb-4">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm text-slate-700">
            <CheckCircle2 className={cn('h-4 w-4 mt-0.5 shrink-0', role === 'teacher' ? 'text-indigo-500' : 'text-emerald-500')} />
            <span>{f}</span>
          </li>
        ))}
      </ul>
      <div className={cn(
        'flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1.5 rounded-lg',
        role === 'teacher' ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'
      )}>
        {role === 'teacher' ? <Shield className="h-3 w-3" /> : <CheckCircle2 className="h-3 w-3" />}
        {note}
      </div>
    </button>
  );
}

/* ============================== AUTH SCREEN =============================== */

function AuthScreen({ role, onBack }: { role: Role; onBack: () => void }) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [className, setClassName] = useState('');
  const [grade, setGrade] = useState('');
  const [section, setSection] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();

  const isTeacher = role === 'teacher';
  const gradient = isTeacher ? 'from-indigo-500 via-violet-500 to-fuchsia-500' : 'from-emerald-500 via-teal-500 to-cyan-500';
  const brandColor = isTeacher ? 'indigo' : 'emerald';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    setTimeout(() => {
      if (mode === 'signin') {
        const r = signIn(email, password, role);
        if (!r.ok) setError(r.error || 'Sign in failed');
      } else {
        if (!name.trim()) { setError('Please enter your full name.'); setLoading(false); return; }
        const r = signUp({ name, email, password, role, subject, className, grade, section });
        if (!r.ok) setError(r.error || 'Sign up failed');
      }
      setLoading(false);
    }, 600);
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-white">
      {/* Left: form */}
      <div className="flex items-center justify-center p-6 sm:p-10 relative">
        <button onClick={onBack} className="absolute top-6 left-6 inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-900">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>

        <div className="w-full max-w-md">
          <div className="flex items-center gap-3 mb-8">
            <div className={cn('h-11 w-11 rounded-2xl bg-gradient-to-br flex items-center justify-center shadow-lg', gradient)}>
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="font-bold text-slate-900 text-lg">GradeSage AI</div>
              <div className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">
                {isTeacher ? 'Teacher portal' : 'Student portal'}
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold text-slate-900 mb-1.5">
              {mode === 'signin' ? 'Welcome back' : 'Create your account'}
            </h1>
            <p className="text-slate-500 text-sm">
              {mode === 'signin'
                ? isTeacher
                  ? 'Sign in with your school or college email to continue.'
                  : 'Sign in with any email to continue.'
                : isTeacher
                  ? 'Sign up with your institutional email to get started.'
                  : 'Sign up to start receiving AI-powered feedback.'}
            </p>
          </div>

          {/* Mode toggle */}
          <div className="flex gap-1 bg-slate-100 rounded-xl p-1 mb-6">
            <button
              type="button"
              onClick={() => { setMode('signin'); setError(null); }}
              className={cn(
                'flex-1 py-2 rounded-lg text-sm font-semibold transition',
                mode === 'signin' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
              )}
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setError(null); }}
              className={cn(
                'flex-1 py-2 rounded-lg text-sm font-semibold transition',
                mode === 'signup' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
              )}
            >
              Sign up
            </button>
          </div>

          {/* Teacher email hint */}
          {isTeacher && (
            <div className="flex items-start gap-2.5 bg-indigo-50 border border-indigo-200 px-3 py-2.5 rounded-xl text-sm text-indigo-800 mb-4">
              <Shield className="h-4 w-4 mt-0.5 shrink-0 text-indigo-600" />
              <div>
                <span className="font-semibold">Institutional email required</span>
                <span className="text-indigo-600"> — use your school or college email </span>
                <span className="text-indigo-500 text-xs">(e.g. .edu, .ac.*, .org, or domains with "school", "college", "university")</span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <Field label="Full name" icon={UserIcon}>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder={isTeacher ? 'Prof. John Smith' : 'Your full name'}
                  className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
                />
              </Field>
            )}
            <Field label="Email" icon={Mail}>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={isTeacher ? 'you@university.edu' : 'you@example.com'}
                className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
              />
            </Field>
            <Field label="Password" icon={Lock}>
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
              />
            </Field>

            {mode === 'signup' && (
              <>
                {isTeacher ? (
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Subject">
                      <input
                        type="text"
                        value={subject}
                        onChange={e => setSubject(e.target.value)}
                        placeholder="e.g. English Literature"
                        className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
                      />
                    </Field>
                    <Field label="Class / Section">
                      <input
                        type="text"
                        value={className}
                        onChange={e => setClassName(e.target.value)}
                        placeholder="e.g. 10-A"
                        className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
                      />
                    </Field>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <Field label="Grade">
                      <select
                        value={grade}
                        onChange={e => setGrade(e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none bg-white"
                      >
                        <option value="">Select…</option>
                        {[6, 7, 8, 9, 10, 11, 12].map(g => <option key={g}>{g}</option>)}
                      </select>
                    </Field>
                    <Field label="Section">
                      <input
                        type="text"
                        value={section}
                        onChange={e => setSection(e.target.value)}
                        placeholder="e.g. A"
                        className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
                      />
                    </Field>
                  </div>
                )}
              </>
            )}

            {error && (
              <div className="flex items-start gap-2 bg-rose-50 border border-rose-200 text-rose-700 px-3 py-2.5 rounded-xl text-sm">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={cn(
                'w-full py-3 rounded-xl text-white font-semibold text-sm shadow-lg transition disabled:opacity-60',
                `bg-gradient-to-r ${gradient}`,
                brandColor === 'indigo' ? 'shadow-indigo-200' : 'shadow-emerald-200'
              )}
            >
              {loading
                ? 'Please wait…'
                : mode === 'signin'
                  ? `Sign in as ${isTeacher ? 'teacher' : 'student'}`
                  : `Create ${isTeacher ? 'teacher' : 'student'} account`}
            </button>
          </form>

          <div className="text-xs text-slate-500 text-center mt-6">
            {mode === 'signin' ? (
              <>Don't have an account?{' '}
                <button onClick={() => { setMode('signup'); setError(null); }} className={cn('font-semibold hover:underline', brandColor === 'indigo' ? 'text-indigo-600' : 'text-emerald-600')}>Sign up</button>
              </>
            ) : (
              <>Already have an account?{' '}
                <button onClick={() => { setMode('signin'); setError(null); }} className={cn('font-semibold hover:underline', brandColor === 'indigo' ? 'text-indigo-600' : 'text-emerald-600')}>Sign in</button>
              </>
            )}
          </div>

          {/* Student easy-access note */}
          {!isTeacher && (
            <div className="mt-5 flex items-start gap-2 bg-emerald-50 border border-emerald-200 px-3 py-2.5 rounded-xl text-xs text-emerald-800">
              <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 shrink-0 text-emerald-600" />
              <span>Students can sign in with <b>any email</b> and password. No invitation needed — just enter your details and you're in.</span>
            </div>
          )}
        </div>
      </div>

      {/* Right: decorative panel */}
      <div className={cn('hidden lg:flex relative overflow-hidden bg-gradient-to-br', gradient)}>
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 70% 60%, white 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="relative flex flex-col justify-center p-12 text-white max-w-xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur border border-white/20 px-3 py-1.5 rounded-full text-xs font-semibold mb-6 w-fit">
            <Target className="h-3.5 w-3.5" />
            {isTeacher ? 'For educators' : 'For learners'}
          </div>
          <h2 className="text-4xl font-bold mb-4 leading-tight">
            {isTeacher
              ? 'Give every student the detailed feedback they deserve — without burning out.'
              : 'Get feedback that actually helps you grow, within seconds of submitting.'}
          </h2>
          <p className="text-white/80 leading-relaxed mb-8">
            {isTeacher
              ? 'Three AI agents — OpenAI for rubric scoring, Claude for holistic feedback, and a RAG pipeline for standards alignment — work together so you can approve grades, not write them.'
              : 'Understand your strengths and exactly what to work on next. AI feedback is criterion-level, actionable, and aligned to your curriculum.'}
          </p>
          <div className="space-y-3">
            {isTeacher
              ? [
                  { icon: Zap, label: 'Grade 30 essays in ~10 minutes' },
                  { icon: CheckCircle2, label: 'Human-in-the-loop for edge cases' },
                  { icon: Sparkles, label: 'Standards-aligned progress reports' },
                ].map(f => (
                  <div key={f.label} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-lg bg-white/15 backdrop-blur flex items-center justify-center">
                      <f.icon className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium">{f.label}</span>
                  </div>
                ))
              : [
                  { icon: Clock, label: 'Feedback in seconds, not days' },
                  { icon: Target, label: 'Know your strengths & next steps' },
                  { icon: MessageSquare, label: 'Personalized, encouraging tone' },
                ].map(f => (
                  <div key={f.label} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-lg bg-white/15 backdrop-blur flex items-center justify-center">
                      <f.icon className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium">{f.label}</span>
                  </div>
                ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================ FIELD ================================== */

function Field({ label, icon: Icon, children }: { label: string; icon?: any; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5 block">{label}</label>
      <div className="relative">
        {Icon && <Icon className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />}
        <div className={cn(Icon ? '[&>input]:pl-9 [&>select]:pl-9' : '', '[&>input]:w-full [&>select]:w-full')}>
          {children}
        </div>
      </div>
    </div>
  );
}
