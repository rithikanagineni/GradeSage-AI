import { useState } from 'react';
import { Brain, Zap, Database, Shield, Sliders, Key, BookOpen, CheckCircle2, AlertCircle, RefreshCw, Upload } from 'lucide-react';
import { cn } from '../utils/cn';
import { useToast } from '../context/ToastContext';

export function AgentsSettings() {
  const toast = useToast();
  const [openAIKey, setOpenAIKey] = useState('sk-••••••••••••••••••••••••••');
  const [claudeKey, setClaudeKey] = useState('sk-ant-••••••••••••••••••••••••');
  const [strictness, setStrictness] = useState(65);
  const [autoApprove, setAutoApprove] = useState(true);
  const [humanThreshold, setHumanThreshold] = useState(75);
  const [ragIndexed, setRagIndexed] = useState(true);

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Agents & RAG Configuration</h1>
        <p className="text-slate-500 text-sm">Configure your multi-agent grading pipeline, model settings, and reference corpus.</p>
      </div>

      {/* Model status cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <ModelCard
          icon={Brain}
          name="OpenAI"
          model="gpt-4o"
          role="Content & rubric scoring"
          status="connected"
          gradient="from-emerald-500 to-teal-500"
        />
        <ModelCard
          icon={Zap}
          name="Anthropic Claude"
          model="claude-sonnet-4"
          role="Holistic feedback & tone"
          status="connected"
          gradient="from-amber-500 to-orange-500"
        />
        <ModelCard
          icon={Database}
          name="RAG Knowledge Base"
          model="Pinecone + text-embedding-3-large"
          role="Standards alignment verification"
          status={ragIndexed ? 'indexed' : 'indexing'}
          gradient="from-sky-500 to-indigo-500"
          docs={1247}
        />
      </div>

      {/* API Keys */}
      <Section title="API credentials" icon={Key}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="OpenAI API Key">
            <input
              type="password"
              value={openAIKey}
              onChange={e => setOpenAIKey(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-mono focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </Field>
          <Field label="Anthropic API Key">
            <input
              type="password"
              value={claudeKey}
              onChange={e => setClaudeKey(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-mono focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </Field>
        </div>
      </Section>

      {/* Agent weights & policies */}
      <Section title="Agent weighting & policies" icon={Sliders}>
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-700">Grading strictness</label>
              <span className="text-sm font-bold text-indigo-600">{strictness}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={strictness}
              onChange={e => setStrictness(Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
            <div className="flex justify-between text-[10px] text-slate-500 uppercase font-semibold mt-1">
              <span>Lenient</span><span>Balanced</span><span>Strict</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <WeightSlider agent="OpenAI" color="emerald" defaultValue={45} />
            <WeightSlider agent="Claude" color="amber" defaultValue={40} />
            <WeightSlider agent="RAG" color="sky" defaultValue={15} />
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
            <div>
              <div className="font-semibold text-slate-900 text-sm">Auto-approve high-confidence grades</div>
              <div className="text-xs text-slate-500">Grades above confidence threshold are sent to students without manual review.</div>
            </div>
            <button
              onClick={() => setAutoApprove(!autoApprove)}
              className={cn(
                'relative h-6 w-11 rounded-full transition-colors',
                autoApprove ? 'bg-indigo-600' : 'bg-slate-300'
              )}
            >
              <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform', autoApprove ? 'translate-x-5' : 'translate-x-0.5')} />
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-700">Human review threshold</label>
              <span className="text-sm font-bold text-amber-600">Below {humanThreshold}% confidence → review</span>
            </div>
            <input
              type="range"
              min={50}
              max={95}
              value={humanThreshold}
              onChange={e => setHumanThreshold(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>
        </div>
      </Section>

      {/* Hallucination guard */}
      <Section title="Hallucination guardrails" icon={Shield}>
        <div className="space-y-3">
          <GuardRow title="Quote verification" desc="All quoted text is cross-checked against the source text in the RAG corpus." defaultOn />
          <GuardRow title="Factual claim checker" desc="Agent claims (e.g., about characters, dates, or events) must be supported by the reference corpus." defaultOn />
          <GuardRow title="Rubric anchoring" desc="Scores must reference specific rubric language; numerical scores must match qualitative descriptors." defaultOn />
          <GuardRow title="Tone policy: encouraging, never dismissive" desc="Feedback tone is checked for motivational framing and growth-mindset language." defaultOn />
        </div>
      </Section>

      {/* RAG corpus */}
      <Section title="RAG reference corpus" icon={BookOpen}>
        <div className="bg-slate-50 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="font-semibold text-slate-900 text-sm">Current index: <span className="text-indigo-600">curriculum-main</span></div>
            <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> {ragIndexed ? '1,247 docs indexed' : 'Indexing…'}
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
            {[
              { label: 'Common Core standards', count: 420 },
              { label: 'Novel texts (6)', count: 182 },
              { label: 'Rubric exemplars', count: 95 },
              { label: 'Past graded essays', count: 550 },
            ].map(d => (
              <div key={d.label} className="bg-white rounded-lg p-3 border border-slate-200">
                <div className="text-sm font-bold text-slate-900">{d.count}</div>
                <div className="text-[10px] text-slate-500 leading-tight">{d.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button onClick={() => toast('Document upload — select files from your device', 'info')} className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-4 py-2 rounded-xl text-sm font-semibold">
            <Upload className="h-4 w-4" /> Upload documents
          </button>
          <button onClick={() => { setRagIndexed(false); setTimeout(() => setRagIndexed(true), 2500); toast('Reindexing RAG corpus…', 'info'); }} className="inline-flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-slate-50">
            <RefreshCw className="h-4 w-4" /> Reindex corpus
          </button>
        </div>
      </Section>

      <div className="flex justify-end gap-3 mt-6">
        <button onClick={() => { setOpenAIKey(''); setClaudeKey(''); setStrictness(65); setAutoApprove(true); setHumanThreshold(75); toast('Settings reset to defaults', 'info'); }} className="px-5 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-semibold text-sm hover:bg-slate-200">Cancel</button>
        <button onClick={() => toast('Configuration saved successfully', 'success')} className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold text-sm shadow-md shadow-indigo-200">Save configuration</button>
      </div>
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-6 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <div className="h-8 w-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
          <Icon className="h-4 w-4" />
        </div>
        <h2 className="font-bold text-slate-900">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}

function ModelCard({ icon: Icon, name, model, role, status, gradient, docs }: any) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
      <div className={`h-1 bg-gradient-to-r ${gradient}`} />
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white`}>
            <Icon className="h-5 w-5" />
          </div>
          <span className={cn(
            'text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1',
            status === 'connected' || status === 'indexed' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
          )}>
            {status === 'connected' ? <><CheckCircle2 className="h-3 w-3" /> Connected</> : status === 'indexed' ? <><CheckCircle2 className="h-3 w-3" /> Indexed</> : <><AlertCircle className="h-3 w-3" /> Indexing</>}
          </span>
        </div>
        <div className="font-bold text-slate-900">{name}</div>
        <div className="text-xs text-slate-500 font-mono mt-0.5">{model}</div>
        <div className="text-xs text-slate-600 mt-2">{role}</div>
        {docs && <div className="text-xs font-semibold text-indigo-600 mt-2">{docs.toLocaleString()} documents</div>}
      </div>
    </div>
  );
}

function WeightSlider({ agent, color, defaultValue }: { agent: string; color: string; defaultValue: number }) {
  const [v, setV] = useState(defaultValue);
  const colorMap: Record<string, string> = {
    emerald: 'accent-emerald-500 text-emerald-700',
    amber: 'accent-amber-500 text-amber-700',
    sky: 'accent-sky-500 text-sky-700',
  };
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <label className="text-xs font-semibold text-slate-700">{agent} weight</label>
        <span className={`text-xs font-bold ${colorMap[color].split(' ').pop()}`}>{v}%</span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={v}
        onChange={e => setV(Number(e.target.value))}
        className={cn('w-full', colorMap[color].split(' ')[0])}
      />
    </div>
  );
}

function GuardRow({ title, desc, defaultOn }: { title: string; desc: string; defaultOn?: boolean }) {
  const [on, setOn] = useState(!!defaultOn);
  return (
    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
      <div className="flex-1 pr-4">
        <div className="font-semibold text-slate-900 text-sm">{title}</div>
        <div className="text-xs text-slate-500">{desc}</div>
      </div>
      <button
        onClick={() => setOn(!on)}
        className={cn('relative h-5 w-9 rounded-full transition-colors shrink-0', on ? 'bg-emerald-500' : 'bg-slate-300')}
      >
        <span className={cn('absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform', on ? 'translate-x-4' : 'translate-x-0.5')} />
      </button>
    </div>
  );
}
