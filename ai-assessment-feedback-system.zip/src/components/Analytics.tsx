import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Download, Filter, Users, Target, FileCheck, Clock, X, Check, FileSpreadsheet, FileJson, FileText as FileTextIcon } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { cn } from '../utils/cn';
import { useAppData } from '../context/AppDataContext';

export function Analytics() {
  const toast = useToast();
  const { data } = useAppData();
  const { students, submissions, assignments } = data;
  const [showFilter, setShowFilter] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'quarter' | 'year'>('month');
  const [classFilter, setClassFilter] = useState('all');
  const [subjectFilter, setSubjectFilter] = useState('all');

  const avgScore = students.length > 0 ? Math.round(students.reduce((a: number, s: any) => a + (s.averageScore || 0), 0) / students.length) : 0;
  const totalGraded = submissions.filter((s: any) => s.status === 'graded').length;
  const activeAssignments = assignments.filter((a: any) => a.status === 'active').length;
  const participationRate = students.length > 0 && activeAssignments > 0 ? Math.round((submissions.length / (students.length * activeAssignments)) * 100) : 0;
  const activeFilterCount = (timeRange !== 'month' ? 1 : 0) + (classFilter !== 'all' ? 1 : 0) + (subjectFilter !== 'all' ? 1 : 0);

  const gradeDistribution = [
    { grade: 'A', count: submissions.filter((s: any) => (s.gradeResult?.percentage || 0) >= 90).length, color: '#10b981' },
    { grade: 'B', count: submissions.filter((s: any) => { const p = s.gradeResult?.percentage || 0; return p >= 80 && p < 90; }).length, color: '#6366f1' },
    { grade: 'C', count: submissions.filter((s: any) => { const p = s.gradeResult?.percentage || 0; return p >= 70 && p < 80; }).length, color: '#f59e0b' },
    { grade: 'D', count: submissions.filter((s: any) => { const p = s.gradeResult?.percentage || 0; return p >= 60 && p < 70; }).length, color: '#ef4444' },
    { grade: 'F', count: submissions.filter((s: any) => (s.gradeResult?.percentage || 0) < 60).length, color: '#94a3b8' },
  ];

  const performanceByStandard: { standard: string; avgScore: number }[] = [];

  const downloadFile = (filename: string, content: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  };

  const exportCSV = () => {
    const rows = [['Student', 'Class', 'Avg Score', 'Submissions']];
    students.forEach((s: any) => rows.push([s.name, s.className, String(s.averageScore || 0), String(s.submissionsCount || 0)]));
    const csv = rows.map(r => r.map((c: any) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    downloadFile('gradesage-class-report.csv', csv, 'text/csv');
    toast('CSV exported — check your downloads', 'success'); setShowExport(false);
  };

  const exportJSON = () => {
    downloadFile('gradesage-data.json', JSON.stringify({ exportedAt: new Date().toISOString(), students, assignments, submissions }, null, 2), 'application/json');
    toast('JSON exported', 'success'); setShowExport(false);
  };

  const exportPDF = () => {
    const w = window.open('', '_blank');
    if (!w) return toast('Allow popups', 'error');
    const rowsHtml = students.map((s: any) => `<tr><td>${s.name}</td><td>${s.className}</td><td>${s.averageScore}%</td><td>${s.submissionsCount}</td></tr>`).join('');
    w.document.write(`<!doctype html><html><head><title>GradeSage Report</title><style>body{font-family:Inter,system-ui,sans-serif;padding:40px;color:#0f172a}h1{margin-bottom:4px}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{padding:10px;border-bottom:1px solid #e2e8f0;text-align:left;font-size:13px}th{background:#f8fafc;font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:#64748b}</style></head><body><h1>Class Performance Report</h1><p style="color:#64748b;margin:0">Generated ${new Date().toLocaleString()}</p><table><thead><tr><th>Student</th><th>Class</th><th>Average</th><th>Submissions</th></tr></thead><tbody>${rowsHtml}</tbody></table><script>window.onload=()=>window.print()</script></body></html>`);
    w.document.close(); toast('PDF opened — use print dialog', 'success'); setShowExport(false);
  };

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div><h1 className="text-2xl font-bold text-slate-900">Analytics & Progress Reports</h1><p className="text-slate-500 text-sm">Class and student performance data.</p></div>
        <div className="flex gap-2 relative">
          <div className="relative">
            <button onClick={() => { setShowFilter(!showFilter); setShowExport(false); }} className={cn('inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition', showFilter || activeFilterCount > 0 ? 'bg-indigo-600 text-white' : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50')}>
              <Filter className="h-4 w-4" /> Filter {activeFilterCount > 0 && <span className="h-5 min-w-[20px] px-1 rounded-full text-[10px] font-bold bg-white text-indigo-600">{activeFilterCount}</span>}
            </button>
            {showFilter && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl z-30 p-4 space-y-4">
                <div className="flex items-center justify-between"><h4 className="font-bold text-slate-900 text-sm">Filters</h4><button onClick={() => setShowFilter(false)}><X className="h-4 w-4 text-slate-400" /></button></div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">Time range</label>
                  <div className="grid grid-cols-4 gap-1 bg-slate-100 rounded-lg p-1">
                    {(['week', 'month', 'quarter', 'year'] as const).map(t => <button key={t} onClick={() => setTimeRange(t)} className={cn('py-1.5 rounded-md text-xs font-semibold capitalize transition', timeRange === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600')}>{t}</button>)}
                  </div>
                </div>
                <div><label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">Class</label><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"><option value="all">All classes</option><option>10-A</option><option>10-B</option></select></div>
                <div><label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">Subject</label><select value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)} className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"><option value="all">All subjects</option><option>English</option><option>Math</option></select></div>
                <div className="flex gap-2 pt-1"><button onClick={() => { setTimeRange('month'); setClassFilter('all'); setSubjectFilter('all'); }} className="flex-1 py-2 rounded-lg bg-slate-100 text-xs font-semibold">Reset</button><button onClick={() => { setShowFilter(false); toast('Filters applied', 'success'); }} className="flex-1 py-2 rounded-lg bg-indigo-600 text-white text-xs font-semibold flex items-center justify-center gap-1"><Check className="h-3.5 w-3.5" /> Apply</button></div>
              </div>
            )}
          </div>

          <div className="relative">
            <button onClick={() => { setShowExport(!showExport); setShowFilter(false); }} className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-3.5 py-2 rounded-xl text-sm font-semibold shadow-md"><Download className="h-4 w-4" /> Export</button>
            {showExport && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl z-30 p-2">
                <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">Choose format</div>
                <button onClick={exportCSV} className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-emerald-50"><div className="h-9 w-9 rounded-lg bg-emerald-100 flex items-center justify-center"><FileSpreadsheet className="h-4 w-4 text-emerald-600" /></div><div><div className="text-sm font-semibold">CSV spreadsheet</div><div className="text-[11px] text-slate-500">Excel / Sheets</div></div></button>
                <button onClick={exportPDF} className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-rose-50"><div className="h-9 w-9 rounded-lg bg-rose-100 flex items-center justify-center"><FileTextIcon className="h-4 w-4 text-rose-600" /></div><div><div className="text-sm font-semibold">PDF report</div><div className="text-[11px] text-slate-500">Print-ready</div></div></button>
                <button onClick={exportJSON} className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-indigo-50"><div className="h-9 w-9 rounded-lg bg-indigo-100 flex items-center justify-center"><FileJson className="h-4 w-4 text-indigo-600" /></div><div><div className="text-sm font-semibold">JSON data</div><div className="text-[11px] text-slate-500">For integrations</div></div></button>
              </div>
            )}
          </div>
        </div>
      </div>

      {students.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center"><TrendingUp className="h-12 w-12 mx-auto text-slate-300 mb-3" /><h3 className="font-bold text-slate-900 text-lg">No data yet</h3><p className="text-sm text-slate-500 mt-1">Add students and assignments to see analytics.</p></div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <KpiCard icon={Target} label="Class average" value={`${avgScore}%`} color="indigo" />
            <KpiCard icon={Users} label="Participation" value={`${participationRate}%`} color="emerald" />
            <KpiCard icon={FileCheck} label="Graded" value={totalGraded.toString()} color="violet" />
            <KpiCard icon={Clock} label="Students" value={students.length.toString()} color="amber" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h3 className="font-bold text-slate-900 mb-4">Grade distribution</h3>
              <div className="h-48 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart><Pie data={gradeDistribution} cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={3} dataKey="count" nameKey="grade">{gradeDistribution.map((g, i) => <Cell key={i} fill={g.color} />)}</Pie><Tooltip /></PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h3 className="font-bold text-slate-900 mb-4">Recent activity</h3>
              <div className="space-y-2">
                {students.slice(0, 5).map((s: any) => (
                  <div key={s.id} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-900">{s.name}</span>
                    <span className="text-xs text-slate-500">{s.submissionsCount || 0} submissions · {(s.averageScore || 0)}% avg</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, color }: any) {
  const cmap: any = { indigo: 'bg-indigo-100 text-indigo-600', emerald: 'bg-emerald-100 text-emerald-600', violet: 'bg-violet-100 text-violet-600', amber: 'bg-amber-100 text-amber-600' };
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <div className="flex justify-between"><div><div className="text-xs text-slate-500 uppercase font-medium">{label}</div><div className="text-2xl font-bold text-slate-900 mt-1">{value}</div></div><div className={cn('h-10 w-10 rounded-xl flex items-center justify-center', cmap[color])}><Icon className="h-5 w-5" /></div></div>
    </div>
  );
}
