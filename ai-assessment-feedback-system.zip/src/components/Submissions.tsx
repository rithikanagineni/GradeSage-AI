import { useState } from 'react';
import { Brain, Zap, Database, CheckCircle2, AlertTriangle, MessageSquare, Target, Award, ChevronDown, ChevronRight, User, Send, Sparkles, Eye, ThumbsUp, ThumbsDown, FileText, RotateCw, CheckSquare, Edit3, X } from 'lucide-react';
import type { Submission, AIGradingResult, Assignment } from '../types';
import { simulateAIGrading } from '../utils/aiGrader';
import { cn } from '../utils/cn';
import { useToast } from '../context/ToastContext';
import { useAppData } from '../context/AppDataContext';

export function Submissions() {
  const { data } = useAppData();
  const { students, assignments, submissions: baseSubs } = data;
  const [selectedId, setSelectedId] = useState<string | null>(baseSubs[0]?.id || null);
  const [liveSubs, setLiveSubs] = useState(baseSubs);
  const [grading, setGrading] = useState<string | null>(null);
  const [filterAssignmentId, setFilterAssignmentId] = useState<string>('a1');
  const [approvedIds, setApprovedIds] = useState<Set<string>>(new Set());
  const [overriddenIds, setOverriddenIds] = useState<Set<string>>(new Set());

  const visibleSubs = liveSubs.filter(s => filterAssignmentId === 'all' ? true : s.assignmentId === filterAssignmentId);
  const selected = liveSubs.find(s => s.id === selectedId);
  const selectedAssignment = selected ? assignments.find(a => a.id === selected.assignmentId) : null;
  const selectedStudent = selected ? students.find(st => st.id === selected.studentId) : null;
  const currentAssignment = assignments.find(a => a.id === filterAssignmentId);

  const runGrading = async (sub: Submission) => {
    if (!sub) return;
    const assignment = assignments.find(a => a.id === sub.assignmentId);
    if (!assignment) return;
    setGrading(sub.id);
    setLiveSubs(prev => prev.map(x => x.id === sub.id ? { ...x, status: 'grading' } : x));
    const result = await simulateAIGrading(sub, assignment);
    setLiveSubs(prev => prev.map(x => x.id === sub.id ? { ...x, status: 'graded', gradeResult: result } : x));
    setGrading(null);
  };

  const handleApprove = (id: string) => {
    setApprovedIds(prev => new Set(prev).add(id));
    setOverriddenIds(prev => { const n = new Set(prev); n.delete(id); return n; });
  };
  const handleOverride = (id: string, newScore: number) => {
    setLiveSubs(prev => prev.map(x => {
      if (x.id !== id || !x.gradeResult) return x;
      const max = x.gradeResult.maxScore;
      const pct = Math.round((newScore / max) * 100);
      const letter = pct >= 97 ? 'A+' : pct >= 93 ? 'A' : pct >= 90 ? 'A-' : pct >= 87 ? 'B+' : pct >= 83 ? 'B' : pct >= 80 ? 'B-' : pct >= 77 ? 'C+' : pct >= 73 ? 'C' : pct >= 70 ? 'C-' : pct >= 60 ? 'D' : 'F';
      return { ...x, gradeResult: { ...x.gradeResult, overallScore: newScore, percentage: pct, gradeLetter: letter } };
    }));
    setOverriddenIds(prev => new Set(prev).add(id));
    setApprovedIds(prev => { const n = new Set(prev); n.delete(id); return n; });
  };

  return (
    <div className="flex h-[calc(100vh-0px)]">
      {/* Submission list */}
      <div className="w-96 border-r border-slate-200 bg-white flex flex-col">
        <div className="p-5 border-b border-slate-100">
          <h1 className="text-xl font-bold text-slate-900 mb-1">Submissions</h1>
          <p className="text-xs text-slate-500 mb-3">
            {currentAssignment ? currentAssignment.title : 'All assignments'} · {visibleSubs.filter(s => s.status === 'graded').length} graded · {visibleSubs.filter(s => s.status !== 'graded').length} pending
          </p>
          <div className="relative">
            <select
              value={filterAssignmentId}
              onChange={(e) => {
                setFilterAssignmentId(e.target.value);
                // Auto-select first submission in the filtered list (or clear)
                const first = liveSubs.find(s => e.target.value === 'all' ? true : s.assignmentId === e.target.value);
                setSelectedId(first?.id || null);
              }}
              className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium pr-9 cursor-pointer focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 outline-none"
            >
              <option value="all">All assignments</option>
              {assignments.map(a => <option key={a.id} value={a.id}>{a.title}</option>)}
            </select>
            <ChevronDown className="h-4 w-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {visibleSubs.length === 0 && (
            <div className="p-8 text-center text-sm text-slate-400">
              <FileText className="h-10 w-10 mx-auto mb-2 text-slate-300" />
              No submissions yet for this assignment.
            </div>
          )}
          {visibleSubs
            .map(sub => {
              const student = students.find(st => st.id === sub.studentId);
              const isSelected = selectedId === sub.id;
              const score = sub.gradeResult?.percentage;
              return (
                <button
                  key={sub.id}
                  onClick={() => setSelectedId(sub.id)}
                  className={cn(
                    'w-full text-left p-4 border-b border-slate-100 flex items-center gap-3 transition',
                    isSelected ? 'bg-indigo-50 border-l-4 border-l-indigo-500' : 'hover:bg-slate-50'
                  )}
                >
                  <div className={cn('h-10 w-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0', student?.avatarColor)}>
                    {student?.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-semibold text-slate-900 text-sm truncate">{student?.name}</div>
                      {sub.status === 'graded' && score !== undefined && (
                        <span className={cn(
                          'text-sm font-bold shrink-0',
                          score >= 90 ? 'text-emerald-600' : score >= 80 ? 'text-indigo-600' : score >= 70 ? 'text-amber-600' : 'text-rose-600'
                        )}>
                          {score}%
                        </span>
                      )}
                      {sub.status === 'pending' && <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">PENDING</span>}
                      {sub.status === 'grading' && <span className="text-[10px] font-bold text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-full flex items-center gap-1"><RotateCw className="h-3 w-3 animate-spin" />GRADING</span>}
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {new Date(sub.submittedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
                    </div>
                    {sub.gradeResult?.humanReviewRecommended && (
                      <div className="flex items-center gap-1 mt-1 text-[10px] font-semibold text-amber-700">
                        <AlertTriangle className="h-3 w-3" /> Needs review
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
        </div>
      </div>

      {/* Detail panel */}
      <div className="flex-1 overflow-y-auto bg-slate-50">
        {selected && selectedAssignment && selectedStudent ? (
          <SubmissionDetail
            key={selected.id}
            submission={selected}
            assignment={selectedAssignment}
            onGrade={() => runGrading(selected)}
            isGrading={grading === selected.id}
            isApproved={approvedIds.has(selected.id)}
            isOverridden={overriddenIds.has(selected.id)}
            onApprove={() => handleApprove(selected.id)}
            onOverride={(newScore: number) => handleOverride(selected.id, newScore)}
            students={students}
          />
        ) : (
          <div className="h-full flex items-center justify-center text-slate-400">
            <div className="text-center">
              <FileText className="h-12 w-12 mx-auto mb-2 text-slate-300" />
              <p className="text-sm">Select a submission to view</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SubmissionDetail({
  submission,
  assignment,
  onGrade,
  isGrading,
  isApproved,
  isOverridden,
  onApprove,
  onOverride,
  students,
}: {
  submission: Submission;
  assignment: Assignment;
  onGrade: () => void;
  isGrading: boolean;
  isApproved: boolean;
  isOverridden: boolean;
  onApprove: () => void;
  onOverride: (newScore: number) => void;
  students: any[];
}) {
  const toast = useToast();
  const result = submission.gradeResult;
  const [tab, setTab] = useState<'feedback' | 'submission' | 'agents'>('feedback');
  const [showOverride, setShowOverride] = useState(false);
  const [overrideScore, setOverrideScore] = useState(result?.overallScore || 0);
  const [overrideNote, setOverrideNote] = useState('');

  return (
    <div>
      {/* Header */}
      <div className="bg-white border-b border-slate-200 p-6 sticky top-0 z-10">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-start gap-4">
            <div className={cn('h-12 w-12 rounded-full flex items-center justify-center text-white font-bold', students.find(s => s.id === submission.studentId)?.avatarColor)}>
              {students.find(s => s.id === submission.studentId)?.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-0.5">{assignment.subject} · {assignment.title}</div>
              <h2 className="font-bold text-slate-900 text-lg">{students.find(s => s.id === submission.studentId)?.name}</h2>
              <div className="text-xs text-slate-500 mt-0.5">
                Submitted {new Date(submission.submittedAt).toLocaleString('en-US', { month: 'long', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {result ? (
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl font-bold text-slate-900">{result.overallScore}</span>
                    <span className="text-sm text-slate-500">/ {result.maxScore}</span>
                    <span className={cn(
                      'ml-2 px-2 py-0.5 rounded-md text-sm font-bold',
                      result.percentage >= 90 ? 'bg-emerald-100 text-emerald-700' : result.percentage >= 80 ? 'bg-indigo-100 text-indigo-700' : result.percentage >= 70 ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                    )}>{result.gradeLetter}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <span>Confidence: {Math.round(result.confidence * 100)}%</span>
                    {result.humanReviewRecommended && (
                      <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-semibold"><AlertTriangle className="h-3 w-3" /> Needs review</span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div />
            )}

            {!result || isGrading ? (
              <button
                onClick={onGrade}
                disabled={isGrading}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-md shadow-indigo-200 disabled:opacity-60"
              >
                {isGrading ? (
                  <><RotateCw className="h-4 w-4 animate-spin" /> Agents grading…</>
                ) : (
                  <><Sparkles className="h-4 w-4" /> Run AI Grading</>
                )}
              </button>
            ) : (
              <div className="flex gap-2 items-center">
                {isApproved && (
                  <span className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-700 px-3 py-2 rounded-xl text-sm font-semibold">
                    <CheckCircle2 className="h-4 w-4" /> Approved & sent
                  </span>
                )}
                {isOverridden && (
                  <span className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-700 px-3 py-2 rounded-xl text-sm font-semibold">
                    <Edit3 className="h-4 w-4" /> Overridden
                  </span>
                )}
                <button
                  onClick={() => {
                    onApprove();
                    toast(`Grade approved (${result?.overallScore}/${result?.maxScore}) and sent to ${students.find(s => s.id === submission.studentId)?.name}`, 'success');
                  }}
                  className={cn(
                    'inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-semibold transition',
                    isApproved ? 'bg-emerald-700 text-white' : 'bg-emerald-600 text-white hover:bg-emerald-700'
                  )}
                >
                  <ThumbsUp className="h-4 w-4" /> {isApproved ? 'Re-approve' : 'Approve'}
                </button>
                <button
                  onClick={() => { setOverrideScore(result?.overallScore || 0); setShowOverride(true); }}
                  className="inline-flex items-center gap-1.5 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-xl text-sm font-semibold hover:bg-slate-50"
                >
                  <ThumbsDown className="h-4 w-4" /> Override
                </button>
              </div>
            )}
          </div>
        </div>

        {result && (
          <div className="flex gap-1 mt-5 border-b border-slate-100 -mb-6">
            {([['feedback', 'Feedback', MessageSquare], ['submission', 'Submission', Eye], ['agents', 'Agent breakdown', Brain]] as const).map(([id, label, Icon]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition',
                  tab === id ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500 hover:text-slate-900'
                )}
              >
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="p-6 max-w-4xl mx-auto">
        {!result && !isGrading && (
          <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
            <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center mx-auto mb-4">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-bold text-slate-900 text-lg mb-2">Ready to grade</h3>
            <p className="text-slate-600 text-sm max-w-md mx-auto mb-4">
              Click "Run AI Grading" to trigger the multi-agent pipeline. OpenAI scores content against the rubric, Claude writes holistic feedback, and the RAG agent verifies curriculum alignment.
            </p>
            <div className="grid grid-cols-3 gap-3 max-w-md mx-auto text-left">
              <AgentMini icon={Brain} name="OpenAI" role="Rubric scoring" color="bg-emerald-50 border-emerald-200 text-emerald-700" />
              <AgentMini icon={Zap} name="Claude" role="Holistic feedback" color="bg-amber-50 border-amber-200 text-amber-700" />
              <AgentMini icon={Database} name="RAG" role="Standards match" color="bg-sky-50 border-sky-200 text-sky-700" />
            </div>
          </div>
        )}

        {isGrading && (
          <div className="bg-white rounded-2xl border border-slate-200 p-8">
            <h3 className="font-bold text-slate-900 mb-4">Agents are working…</h3>
            <div className="space-y-3">
              <GradingStep icon={Brain} label="OpenAI analyzing content against rubric…" duration="~2.3s" />
              <GradingStep icon={Zap} label="Claude composing holistic feedback & tone check…" duration="~1.9s" delayed />
              <GradingStep icon={Database} label="RAG pipeline matching to Common Core standards…" duration="~0.4s" delayed />
              <GradingStep icon={CheckCircle2} label="Consensus scoring & hallucination check…" duration="~0.8s" delayed />
            </div>
          </div>
        )}

        {result && tab === 'feedback' && <FeedbackView result={result} assignment={assignment} />}
        {result && tab === 'submission' && <SubmissionContent submission={submission} />}
        {result && tab === 'agents' && <AgentBreakdown result={result} />}
      </div>

      {/* Override modal */}
      {showOverride && result && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4" onClick={() => setShowOverride(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full" onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                  <Edit3 className="h-4 w-4" />
                </div>
                <h3 className="font-bold text-slate-900">Override AI grade</h3>
              </div>
              <button onClick={() => setShowOverride(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">New score</label>
                  <span className="text-sm font-bold text-slate-900">{overrideScore} / {result.maxScore}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={result.maxScore}
                  value={overrideScore}
                  onChange={(e) => setOverrideScore(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>0</span>
                  <span className="text-amber-600 font-semibold">AI: {result.overallScore}</span>
                  <span>{result.maxScore}</span>
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide mb-1.5 block">Note (optional)</label>
                <textarea
                  value={overrideNote}
                  onChange={(e) => setOverrideNote(e.target.value)}
                  placeholder="Explain why you're overriding the AI score…"
                  className="w-full p-3 border border-slate-200 rounded-xl text-sm min-h-[80px] focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={() => setShowOverride(false)} className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-semibold text-sm hover:bg-slate-200">Cancel</button>
                <button
                  onClick={() => {
                    onOverride(overrideScore);
                    setShowOverride(false);
                    toast(`Score overridden: ${result.overallScore} → ${overrideScore}`, 'success');
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-600 text-white font-semibold text-sm hover:bg-amber-700"
                >
                  Save override
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AgentMini({ icon: Icon, name, role, color }: any) {
  return (
    <div className={cn('p-3 rounded-xl border text-xs', color)}>
      <Icon className="h-4 w-4 mb-1.5" />
      <div className="font-bold text-sm">{name}</div>
      <div className="opacity-80">{role}</div>
    </div>
  );
}

function GradingStep({ icon: Icon, label, duration, delayed }: { icon: any; label: string; duration: string; delayed?: boolean }) {
  const [done, setDone] = useState(delayed ? false : true);
  setTimeout(() => !delayed ? null : setDone(true), delayed ? 800 : 0);
  return (
    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
      <div className={cn('h-9 w-9 rounded-lg flex items-center justify-center shrink-0', done ? 'bg-emerald-100 text-emerald-600' : 'bg-indigo-100 text-indigo-600')}>
        {done ? <CheckCircle2 className="h-5 w-5" /> : <Icon className="h-5 w-5 animate-pulse" />}
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium text-slate-900">{label}</div>
        <div className="text-xs text-slate-500">{duration}</div>
      </div>
    </div>
  );
}

function FeedbackView({ result, assignment }: { result: AIGradingResult; assignment: Assignment }) {
  const toast = useToast();
  return (
    <div className="space-y-5">
      {/* Holistic comment */}
      <div className="bg-gradient-to-br from-indigo-50 via-white to-violet-50 border border-indigo-200 rounded-2xl p-6">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center shrink-0">
            <MessageSquare className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-bold text-slate-900">Teacher Feedback (AI-drafted, you approve)</h3>
              <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-semibold">HOLISTIC</span>
            </div>
            <p className="text-slate-700 leading-relaxed text-sm">{result.holisticComment}</p>
          </div>
        </div>
      </div>

      {/* Strengths / Growth / Next steps */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <InfoCard icon={Award} title="Strengths" items={result.summaryStrengths} color="emerald" />
        <InfoCard icon={Target} title="Areas for growth" items={result.summaryAreasForGrowth} color="amber" />
        <InfoCard icon={Send} title="Next steps" items={result.nextSteps} color="indigo" />
      </div>

      {/* Rubric breakdown */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h3 className="font-bold text-slate-900 flex items-center gap-2"><CheckSquare className="h-5 w-5 text-indigo-600" /> Rubric criteria</h3>
        </div>
        <div className="divide-y divide-slate-100">
          {result.feedback.length > 0 && result.feedback[0].criterion ? result.feedback.map((f, i) => {
            const pct = (f.score / f.maxScore) * 100;
            return (
              <div key={i} className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-semibold text-slate-900 text-sm">{f.criterion}</div>
                  <div className="text-sm font-bold text-slate-900">{f.score}<span className="text-slate-400 font-normal"> / {f.maxScore}</span></div>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden mb-2">
                  <div
                    className={cn(
                      'h-full rounded-full',
                      pct >= 85 ? 'bg-emerald-500' : pct >= 70 ? 'bg-indigo-500' : pct >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                    )}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{f.comment}</p>
                {f.highlights && f.highlights.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    {f.highlights.map((h, j) => (
                      <div key={j} className={cn(
                        'flex items-start gap-2 text-xs p-2 rounded-lg',
                        h.type === 'strength' ? 'bg-emerald-50 text-emerald-900' : h.type === 'improvement' ? 'bg-amber-50 text-amber-900' : 'bg-slate-50 text-slate-700'
                      )}>
                        {h.type === 'strength' ? <ThumbsUp className="h-3.5 w-3.5 mt-0.5 shrink-0" /> : h.type === 'improvement' ? <Target className="h-3.5 w-3.5 mt-0.5 shrink-0" /> : <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />}
                        <span>"{h.text}"</span>
                      </div>
                    ))}
                  </div>
                )}
                {f.suggestions && f.suggestions.length > 0 && (
                  <div className="mt-2">
                    {f.suggestions.map((s, j) => (
                      <div key={j} className="text-xs text-indigo-700 bg-indigo-50 px-2 py-1 rounded inline-block mr-1.5 mt-1">💡 {s}</div>
                    ))}
                  </div>
                )}
              </div>
            );
          }) : assignment.rubric.map((r, i) => (
              <div key={i} className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-semibold text-slate-900 text-sm">{r.criterion}</div>
                  <div className="text-sm font-bold text-slate-900">—<span className="text-slate-400 font-normal"> / {r.maxPoints}</span></div>
                </div>
                <p className="text-sm text-slate-600">{r.description}</p>
              </div>
            ))}
        </div>
      </div>

      {/* Reply box */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <div className="flex items-center gap-3 mb-3">
          <User className="h-5 w-5 text-slate-400" />
          <input type="text" placeholder="Add your own comment (appended to feedback)…" className="flex-1 text-sm outline-none placeholder:text-slate-400" />
        </div>
        <div className="flex items-center justify-between">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
            Hallucination check passed ({Math.round(result.hallucinationCheck.score * 100)}%)
          </div>
          <div className="flex gap-2">
            <button onClick={() => toast('Regenerating feedback…', 'info')} className="text-sm text-slate-600 px-3 py-1.5 rounded-lg hover:bg-slate-100 font-medium">Regenerate</button>
            <button onClick={() => toast('Feedback sent to student', 'success')} className="text-sm bg-indigo-600 text-white px-4 py-1.5 rounded-lg font-semibold hover:bg-indigo-700">Send feedback</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ icon: Icon, title, items, color }: { icon: any; title: string; items: string[]; color: 'emerald' | 'amber' | 'indigo' }) {
  const colors = {
    emerald: 'border-emerald-200 bg-emerald-50/50 text-emerald-700',
    amber: 'border-amber-200 bg-amber-50/50 text-amber-700',
    indigo: 'border-indigo-200 bg-indigo-50/50 text-indigo-700',
  };
  return (
    <div className={cn('rounded-2xl border bg-white p-5', colors[color].split(' ')[0])}>
      <div className="flex items-center gap-2 mb-3">
        <div className={cn('h-8 w-8 rounded-lg flex items-center justify-center', colors[color])}>
          <Icon className="h-4 w-4" />
        </div>
        <h4 className="font-bold text-slate-900 text-sm">{title}</h4>
      </div>
      <ul className="space-y-2">
        {items.map((it, i) => (
          <li key={i} className="text-xs text-slate-700 flex items-start gap-2 leading-relaxed">
            <span className={cn('mt-1.5 h-1 w-1 rounded-full shrink-0', colors[color].includes('emerald') ? 'bg-emerald-500' : colors[color].includes('amber') ? 'bg-amber-500' : 'bg-indigo-500')} />
            {it}
          </li>
        ))}
      </ul>
    </div>
  );
}

function SubmissionContent({ submission }: { submission: Submission }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-8">
      <div className="prose prose-slate max-w-none text-slate-800 leading-relaxed whitespace-pre-wrap text-sm" style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7 }}>
        {submission.content}
      </div>
    </div>
  );
}

function AgentBreakdown({ result }: { result: AIGradingResult }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <AgentCard
          icon={Brain}
          name="OpenAI"
          role="Content & Rubric Scoring"
          score={result.agentBreakdown.openai.score}
          time={`${result.agentBreakdown.openai.ms}ms`}
          gradient="from-emerald-500 to-teal-500"
          observations={result.agentBreakdown.openai.observations}
        />
        <AgentCard
          icon={Zap}
          name="Claude"
          role="Holistic Feedback & Tone"
          score={result.agentBreakdown.claude.score}
          time={`${result.agentBreakdown.claude.ms}ms`}
          gradient="from-amber-500 to-orange-500"
          observations={result.agentBreakdown.claude.observations}
        />
        <AgentCard
          icon={Database}
          name="RAG Pipeline"
          role="Curriculum Alignment"
          score={Math.round(result.agentBreakdown.rag.alignment * 100)}
          time={`${result.agentBreakdown.rag.ms}ms`}
          gradient="from-sky-500 to-indigo-500"
          observations={[
            `Matched ${result.agentBreakdown.rag.matchedStandards.length} standards`,
            ...result.agentBreakdown.rag.matchedStandards.map(s => `• ${s}`),
          ]}
          isRAG
        />
      </div>

      {/* Consensus explanation */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2"><Sparkles className="h-5 w-5 text-indigo-500" /> Consensus scoring</h3>
        <p className="text-sm text-slate-600 mb-4 leading-relaxed">
          Final score is a weighted average of the three agents: OpenAI (45%) handles objective rubric alignment, Claude (40%) handles qualitative writing quality, and RAG (15%) verifies curriculum standard coverage.
          When agents disagree by more than 10 points, the submission is automatically flagged for human review.
        </p>
        <div className="bg-slate-50 rounded-xl p-4 font-mono text-xs text-slate-700 space-y-1">
          <div className="text-slate-500">// Weighted consensus formula</div>
          <div>openai    × 0.45 = {Math.round(result.agentBreakdown.openai.score * 0.45)}</div>
          <div>claude    × 0.40 = {Math.round(result.agentBreakdown.claude.score * 0.40)}</div>
          <div>rag       × 0.15 = {Math.round(result.agentBreakdown.rag.alignment * 100 * 0.15)}</div>
          <div className="border-t border-slate-200 pt-1 text-slate-900 font-bold">FINAL     = <span className="text-indigo-600">{result.overallScore}/100</span> ({result.gradeLetter})</div>
        </div>
      </div>

      {/* Hallucination check */}
      <div className={cn(
        'rounded-2xl p-5 border flex items-start gap-4',
        result.hallucinationCheck.passed ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'
      )}>
        {result.hallucinationCheck.passed ? (
          <CheckCircle2 className="h-6 w-6 text-emerald-600 shrink-0" />
        ) : (
          <AlertTriangle className="h-6 w-6 text-rose-600 shrink-0" />
        )}
        <div>
          <h4 className="font-bold text-slate-900 mb-0.5">
            Hallucination check: {result.hallucinationCheck.passed ? 'PASSED' : 'FLAGGED'}
          </h4>
          <p className="text-sm text-slate-700">Confidence: {Math.round(result.hallucinationCheck.score * 100)}% — {result.hallucinationCheck.notes}</p>
        </div>
      </div>
    </div>
  );
}

function AgentCard({ icon: Icon, name, role, score, time, gradient, observations, isRAG }: any) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <div className={`h-1.5 bg-gradient-to-r ${gradient}`} />
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white`}>
              <Icon className="h-5 w-5" />
            </div>
            <div>
              <div className="font-bold text-slate-900 text-sm">{name}</div>
              <div className="text-[11px] text-slate-500">{role}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xl font-bold text-slate-900">{score}{isRAG ? '%' : ''}</div>
            <div className="text-[10px] text-slate-400 font-mono">{time}</div>
          </div>
        </div>
        <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between text-xs font-semibold text-indigo-600 hover:text-indigo-700 mt-2">
          <span>{open ? 'Hide observations' : 'View observations'}</span>
          {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        </button>
        {open && (
          <ul className="mt-3 space-y-1.5 border-t border-slate-100 pt-3">
            {observations.map((o: string, i: number) => (
              <li key={i} className="text-xs text-slate-600 leading-relaxed">{o}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
