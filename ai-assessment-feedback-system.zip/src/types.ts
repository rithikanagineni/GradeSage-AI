export type Rubric = {
  id: string;
  criterion: string;
  maxPoints: number;
  weight: number;
  description: string;
};

export type Assignment = {
  id: string;
  title: string;
  subject: string;
  description: string;
  type: 'essay' | 'short_answer' | 'problem_set' | 'quiz' | 'project';
  dueDate: string;
  totalPoints: number;
  rubric: Rubric[];
  status: 'draft' | 'active' | 'closed';
  questionBank?: string[];
  referenceMaterials?: string[];
  standardsTags?: string[];
  createdAt: string;
};

export type FeedbackItem = {
  criterion: string;
  score: number;
  maxScore: number;
  comment: string;
  highlights?: { text: string; type: 'strength' | 'improvement' | 'note' }[];
  suggestions?: string[];
};

export type AIGradingResult = {
  submissionId: string;
  overallScore: number;
  maxScore: number;
  gradeLetter: string;
  percentage: number;
  completedAt: string;
  confidence: number;
  agentBreakdown: {
    openai: { role: string; score: number; observations: string[]; ms: number };
    claude: { role: string; score: number; observations: string[]; ms: number };
    rag: { role: string; matchedStandards: string[]; alignment: number; ms: number };
  };
  feedback: FeedbackItem[];
  summaryStrengths: string[];
  summaryAreasForGrowth: string[];
  nextSteps: string[];
  holisticComment: string;
  hallucinationCheck: { passed: boolean; score: number; notes: string };
  humanReviewRecommended: boolean;
};

export type Submission = {
  id: string;
  assignmentId: string;
  studentId: string;
  submittedAt: string;
  content: string;
  status: 'pending' | 'grading' | 'graded' | 'reviewed';
  gradeResult?: AIGradingResult;
  teacherOverride?: { score: number; note: string };
};

export type Student = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatarColor: string;
  grade: string;
  className: string;
  averageScore?: number;
  submissionsCount?: number;
  strengths?: string[];
  growthAreas?: string[];
};

export type View = 'dashboard' | 'assignments' | 'submissions' | 'analytics' | 'students' | 'settings' | 'profile';
