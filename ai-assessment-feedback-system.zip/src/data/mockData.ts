import type { Assignment, Student, Submission } from '../types';

export const students: Student[] = [];

export const assignments: Assignment[] = [];

export const submissions: Submission[] = [];

export const gradingActivity: { time: string; agent: string; action: string; assignment: string }[] = [];

export const performanceByStandard: { standard: string; avgScore: number }[] = [];

export const weeklyTimeSaved = [
  { week: 'Wk 1', manualHours: 0, aiHours: 0 },
  { week: 'Wk 2', manualHours: 0, aiHours: 0 },
  { week: 'Wk 3', manualHours: 0, aiHours: 0 },
  { week: 'Wk 4', manualHours: 0, aiHours: 0 },
  { week: 'Wk 5', manualHours: 0, aiHours: 0 },
  { week: 'Wk 6', manualHours: 0, aiHours: 0 },
];
