import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { AppDataProvider } from './context/AppDataContext';
import { AuthFlow } from './components/auth/AuthFlow';
import { TeacherPortal } from './TeacherPortal';
import { StudentPortal } from './components/student/StudentPortal';

function Router() {
  const { user } = useAuth();
  if (!user) return <AuthFlow />;
  if (user.role === 'teacher') return <TeacherPortal />;
  return <StudentPortal />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppDataProvider>
        <ToastProvider>
          <Router />
        </ToastProvider>
      </AppDataProvider>
    </AuthProvider>
  );
}
