import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Assignments } from './components/Assignments';
import { Submissions } from './components/Submissions';
import { Analytics } from './components/Analytics';
import { Students } from './components/Students';
import { AgentsSettings } from './components/AgentsSettings';
import { TeacherProfile } from './components/TeacherProfile';
import type { View } from './types';

export function TeacherPortal() {
  const [view, setView] = useState<View>('dashboard');

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar current={view} onChange={setView} />
      <main className="flex-1 min-w-0">
        {view === 'dashboard' && <Dashboard onNavigate={setView} />}
        {view === 'assignments' && <Assignments />}
        {view === 'submissions' && <Submissions />}
        {view === 'analytics' && <Analytics />}
        {view === 'students' && <Students />}
        {view === 'settings' && <AgentsSettings />}
        {view === 'profile' && <TeacherProfile />}
      </main>
    </div>
  );
}
