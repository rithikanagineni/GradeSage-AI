import type { AIGradingResult, Assignment, Submission } from '../types';

/**
 * Simulate multi-agent AI grading that combines:
 *  - OpenAI agent for rubric-level content scoring
 *  - Claude agent for holistic/qualitative feedback
 *  - RAG agent for curriculum standards alignment
 *
 * The agents "vote" and a consensus score is produced.
 * Low-confidence or edge cases flag for human review.
 */

export async function simulateAIGrading(
  submission: Submission,
  assignment: Assignment
): Promise<AIGradingResult> {
  // Simulate processing latency
  const baseDelay = 1800;
  await new Promise((r) => setTimeout(r, baseDelay));

  const content = submission.content.toLowerCase();
  const wordCount = submission.content.split(/\s+/).length;

  // Heuristic scoring (simulating LLM judgment)
  const hasQuotes = /"[^"]+"\s*\(/.test(submission.content) || /“[^”]+”/.test(submission.content);
  const hasStructure = /conclusion|in (summary|closing)|first|second|finally/i.test(content);
  const hasDepth = /symbol|theme|american dream|class|consumer|moral/i.test(content);
  const lengthPenalty = wordCount < 200 ? 0.5 : wordCount < 400 ? 0.75 : 1;
  const quoteBonus = hasQuotes ? 1 : 0.82;
  const structureBonus = hasStructure ? 1 : 0.88;
  const depthBonus = hasDepth ? 1 : 0.70;

  const baseOpenAI = Math.round(78 * quoteBonus * structureBonus * lengthPenalty);
  const baseClaude = Math.round(80 * depthBonus * structureBonus * lengthPenalty);
  const ragAlign = Math.min(
    0.98,
    Math.round(
      ((hasQuotes ? 0.92 : 0.7) + (hasDepth ? 0.95 : 0.6) + (wordCount > 300 ? 0.88 : 0.7)) / 3 * 100
    ) / 100
  );

  const openaiScore = Math.min(100, baseOpenAI + Math.round((Math.random() - 0.3) * 4));
  const claudeScore = Math.min(100, baseClaude + Math.round((Math.random() - 0.3) * 4));
  const weightedAvg = Math.round(openaiScore * 0.45 + claudeScore * 0.4 + ragAlign * 100 * 0.15);
  const overallScore = Math.max(0, Math.min(100, weightedAvg));

  const letter =
    overallScore >= 97 ? 'A+' :
    overallScore >= 93 ? 'A' :
    overallScore >= 90 ? 'A-' :
    overallScore >= 87 ? 'B+' :
    overallScore >= 83 ? 'B' :
    overallScore >= 80 ? 'B-' :
    overallScore >= 77 ? 'C+' :
    overallScore >= 73 ? 'C' :
    overallScore >= 70 ? 'C-' :
    overallScore >= 67 ? 'D+' :
    overallScore >= 60 ? 'D' : 'F';

  const confidence =
    Math.abs(openaiScore - claudeScore) < 5 ? 0.92 :
    Math.abs(openaiScore - claudeScore) < 10 ? 0.82 : 0.68;
  const needsHuman = confidence < 0.75 || overallScore < 60 || wordCount < 150;

  const strengths: string[] = [];
  const growth: string[] = [];
  const nextSteps: string[] = [];

  if (hasDepth) strengths.push('Engages with thematic ideas beyond plot summary');
  else { growth.push('Focus more on analysis than plot summary'); nextSteps.push('Add at least two sentences per body paragraph that interpret why a detail matters thematically'); }
  if (hasQuotes) strengths.push('Attempts textual evidence');
  else { growth.push('Include direct quotations from the text with citations'); nextSteps.push('Add 3 direct quotations with page numbers in MLA format'); }
  if (hasStructure) strengths.push('Basic organizational structure is present');
  else { growth.push('Develop clearer introduction, body, and conclusion'); nextSteps.push('Add an intro with thesis, three body paragraphs, and a conclusion'); }
  if (wordCount < 300) { growth.push(`Submission is brief (${wordCount} words) — expand to 500+ words`); nextSteps.push('Develop each body paragraph to 100+ words'); }
  if (wordCount >= 500) strengths.push('Submission length meets the assignment requirements');

  if (strengths.length === 0) strengths.push('Submitted the assignment on time');

  const rubricFeedback = assignment.rubric.map((r, i) => {
    const ratio = overallScore / 100;
    const score = Math.round(r.maxPoints * ratio * (0.92 + Math.random() * 0.16));
    const finalScore = Math.min(r.maxPoints, Math.max(Math.round(r.maxPoints * 0.4), score));
    return {
      criterion: r.criterion,
      score: finalScore,
      maxScore: r.maxPoints,
      comment: i === 0
        ? 'The AI evaluated this criterion against the rubric. See summary below for targeted suggestions.'
        : 'Evaluated against rubric descriptors.',
      suggestions: [r.description],
    };
  });

  const holistic = overallScore >= 90
    ? `Excellent work. You demonstrate strong analytical skills and engagement with the text. Your argument is clear and well-supported.`
    : overallScore >= 80
    ? `Good work with a clear foundation. Some areas need strengthening, but you show genuine engagement with the material.`
    : overallScore >= 70
    ? `You have the basics here but the essay needs significant development in evidence, analysis, or organization.`
    : `This submission is incomplete or does not yet meet the assignment requirements. Let's meet to discuss how to approach the revision.`;

  return {
    submissionId: submission.id,
    overallScore,
    maxScore: assignment.totalPoints,
    percentage: overallScore,
    gradeLetter: letter,
    completedAt: new Date().toISOString(),
    confidence,
    agentBreakdown: {
      openai: {
        role: 'Content & Rubric Scoring',
        score: openaiScore,
        observations: [
          hasQuotes ? 'Quotations detected' : 'Few or no direct quotations found',
          hasStructure ? 'Essay structure present' : 'Structure unclear — intro/conclusion not clearly marked',
          wordCount < 200 ? `Submission is very short (${wordCount} words)` : `Length: ~${wordCount} words`,
          hasDepth ? 'Thematic language present' : 'Relies heavily on plot summary',
        ],
        ms: 2200 + Math.round(Math.random() * 400),
      },
      claude: {
        role: 'Holistic Feedback & Tone',
        score: claudeScore,
        observations: [
          hasDepth ? 'Tone suggests engagement with the prompt' : 'Writing stays at the surface level',
          overallScore >= 85 ? 'Authentic student voice comes through' : 'Voice is less developed',
          needsHuman ? 'Score variance suggests human review is warranted' : 'Consensus is strong',
        ],
        ms: 1800 + Math.round(Math.random() * 300),
      },
      rag: {
        role: 'Curriculum Alignment (RAG)',
        matchedStandards: assignment.standardsTags || [],
        alignment: ragAlign,
        ms: 380 + Math.round(Math.random() * 100),
      },
    },
    feedback: rubricFeedback,
    summaryStrengths: strengths,
    summaryAreasForGrowth: growth,
    nextSteps,
    holisticComment: holistic,
    hallucinationCheck: {
      passed: true,
      score: Math.round((0.92 + Math.random() * 0.06) * 100) / 100,
      notes: 'Quotations and claims verified against reference corpus via RAG pipeline.',
    },
    humanReviewRecommended: needsHuman,
  };
}
